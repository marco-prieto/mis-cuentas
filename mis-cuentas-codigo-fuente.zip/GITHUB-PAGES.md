# Mis Cuentas en GitHub Pages

La aplicación funciona enteramente en el navegador. El código publicado no necesita
ChatGPT, Supabase, claves API ni un servidor de aplicación. Los movimientos, categorías,
presupuestos, medios de pago y préstamos se guardan en el localStorage de cada navegador.

## Desarrollo

Requiere Node.js 22.13 o superior.

```sh
npm ci
npm run dev:pages
```

## Publicación

1. Subir este proyecto a la rama `main` de un repositorio de GitHub.
2. En Settings → Pages, seleccionar GitHub Actions como fuente.
3. El workflow `.github/workflows/pages.yml` compila y publica la aplicación.

También se puede compilar con `npm run build:pages` y alojar el contenido de
`dist-pages` en cualquier servidor de archivos estáticos.

La configuración original de Sites se conserva; GitHub Pages utiliza su entrada y
configuración independientes, sin cargar el servidor ni los plugins de Sites.

## Datos

Cada dispositivo conserva su propia información; no hay sincronización de cuentas.
Al cambiar de dominio los datos anteriores no se trasladan automáticamente.
El respaldo Excel de Plan conserva movimientos, presupuestos, categorías y medios
de pago, pero actualmente no incluye los préstamos. No borres el almacenamiento del
navegador si necesitas conservar información que aún no hayas respaldado.

El cálculo de préstamos es referencial y utiliza la TCEA como costo financiero
equivalente, con días reales y base anual de 365 días.
