"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { ArrowDownLeft, ArrowLeft, ArrowRight, ArrowUpRight, Baby, BarChart3, BookOpen, BriefcaseBusiness, BusFront, Calculator, CalendarRange, Car, ChevronRight, CircleDollarSign, Clapperboard, Coffee, CreditCard, Download, Dumbbell, FileSpreadsheet, FileText, Fuel, Gamepad2, Gift, GraduationCap, HeartPulse, Home, House, Landmark, MessageSquareText, MoreHorizontal, PawPrint, Pencil, PiggyBank, Plane, Plus, ReceiptText, Settings2, Shirt, ShoppingBag, Smartphone, Sparkles, Stethoscope, Trash2, Upload, Utensils, WalletCards, Wrench, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Sheet, SheetContent, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type Kind = "expense" | "income";
type Entry = { id: string; kind: Kind; amount: number; date: string; category: string; subcategory: string; note: string; recurring: boolean; paymentSource: string };
type Categories = Record<string, string[]>;
type CategoryAppearance = { icon: CategoryIconKey; color: string };
type CategoryAppearances = Record<string, CategoryAppearance>;
type Loan = { id: string; name: string; principal: number; tcea: number; months: number; startDate: string; firstPaymentDate?: string; paidMonths?: number };
type Tab = "home" | "movements" | "plan" | "progress" | "loans";
type PeriodMode = "week" | "month" | "year";
type ImportPreview = { fileName: string; entries: Entry[]; budgets: Record<string, number>; categories: Categories; categoryAppearances: CategoryAppearances; paymentMethods: string[] };

const DEFAULT_CATEGORIES: Categories = {
  Alimentación: ["Despensa", "Restaurantes", "Delivery", "Golosinas/Snacks"],
  Transporte: ["Taxi/App", "Transporte público", "Combustible", "Estacionamiento"],
  Salud: ["Consultas", "Medicinas", "Seguro", "Emergencias"],
  Educación: ["Cursos", "Libros/Materiales", "Mensualidad", "Certificaciones"],
  Vivienda: ["Alquiler/Hipoteca", "Servicios", "Mantenimiento", "Muebles/Enseres"],
  Entretenimiento: ["Streaming", "Salidas", "Hobbies", "Viajes"],
  "Ahorro e inversión": ["Fondo de emergencia", "Inversiones", "Meta de ahorro"],
  Otros: ["Ropa", "Regalos", "Mascotas", "Imprevistos"],
};
const DEFAULT_BUDGETS: Record<string, number> = { Alimentación: 660, Transporte: 500, Salud: 300, Educación: 220, Vivienda: 1100, Entretenimiento: 500, "Ahorro e inversión": 420, Otros: 420 };
const DEFAULT_PAYMENT_METHODS = ["Efectivo", "Yape", "Plin", "BCP Débito", "BCP Crédito", "Interbank Débito", "Interbank Crédito", "BBVA Débito", "BBVA Crédito", "Scotiabank Débito", "Scotiabank Crédito"];
const INCOME_SOURCES = ["Trabajo principal", "Honorarios", "Bonificación", "Venta", "Otro ingreso"];
const COLORS = ["#2f6b65", "#d1a039", "#b95f4d", "#5f8f73", "#6f719a", "#47718e", "#956e40", "#77856f"];
const CATEGORY_ICONS = {
  house: House, food: Utensils, car: Car, health: HeartPulse, education: GraduationCap, entertainment: Clapperboard,
  savings: PiggyBank, shopping: ShoppingBag, clothes: Shirt, pets: PawPrint, travel: Plane, gift: Gift,
  repairs: Wrench, fitness: Dumbbell, family: Baby, work: BriefcaseBusiness, phone: Smartphone, coffee: Coffee,
  games: Gamepad2, money: CircleDollarSign, bus: BusFront, books: BookOpen, fuel: Fuel, doctor: Stethoscope,
} as const;
type CategoryIconKey = keyof typeof CATEGORY_ICONS;
const ICON_CHOICES = Object.keys(CATEGORY_ICONS) as CategoryIconKey[];
const CATEGORY_COLOR_CHOICES = ["#2f6b65", "#d1a039", "#b95f4d", "#5f8f73", "#6f719a", "#47718e", "#956e40", "#77856f", "#b66b8a", "#3087a3", "#b46d3d", "#637d3f"];
const DEFAULT_CATEGORY_APPEARANCES: CategoryAppearances = {
  Alimentación: { icon: "food", color: "#d1a039" }, Transporte: { icon: "car", color: "#47718e" },
  Salud: { icon: "health", color: "#b95f4d" }, Educación: { icon: "education", color: "#6f719a" },
  Vivienda: { icon: "house", color: "#2f6b65" }, Entretenimiento: { icon: "entertainment", color: "#b66b8a" },
  "Ahorro e inversión": { icon: "savings", color: "#5f8f73" }, Otros: { icon: "shopping", color: "#77856f" },
};
const SEED: Entry[] = [
  { id: "i1", kind: "income", amount: 4200, date: "2026-09-01", category: "Trabajo principal", subcategory: "Recurrente mensual", note: "Sueldo mensual", recurring: true, paymentSource: "BCP Débito" },
  { id: "i2", kind: "income", amount: 420, date: "2026-09-12", category: "Honorarios", subcategory: "Extraordinario", note: "Recibo por honorarios", recurring: false, paymentSource: "Yape" },
  { id: "e1", kind: "expense", amount: 1050, date: "2026-09-02", category: "Vivienda", subcategory: "Alquiler/Hipoteca", note: "Alquiler", recurring: true, paymentSource: "BCP Débito" },
  { id: "e2", kind: "expense", amount: 260, date: "2026-09-05", category: "Alimentación", subcategory: "Despensa", note: "Compra semanal", recurring: false, paymentSource: "Interbank Débito" },
  { id: "e3", kind: "expense", amount: 96, date: "2026-09-11", category: "Alimentación", subcategory: "Delivery", note: "Pedidos de la semana", recurring: false, paymentSource: "Yape" },
  { id: "e4", kind: "expense", amount: 310, date: "2026-09-14", category: "Transporte", subcategory: "Taxi/App", note: "Movilidad", recurring: false, paymentSource: "Yape" },
  { id: "e5", kind: "expense", amount: 234, date: "2026-09-16", category: "Entretenimiento", subcategory: "Salidas", note: "Cena con amigos", recurring: false, paymentSource: "BCP Crédito" },
  { id: "e6", kind: "expense", amount: 84, date: "2026-09-17", category: "Salud", subcategory: "Medicinas", note: "Farmacia", recurring: false, paymentSource: "Efectivo" },
];

const DEMO_HISTORY: Entry[] = [
  { id: "demo-2026-06-income-1", kind: "income", amount: 4200, date: "2026-06-01", category: "Trabajo principal", subcategory: "Recurrente mensual", note: "Sueldo mensual", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-06-income-2", kind: "income", amount: 450, date: "2026-06-18", category: "Bonificación", subcategory: "Extraordinario", note: "Bono por resultados", recurring: false, paymentSource: "BCP Débito" },
  { id: "demo-2026-06-02", kind: "expense", amount: 1050, date: "2026-06-02", category: "Vivienda", subcategory: "Alquiler/Hipoteca", note: "Alquiler", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-06-04", kind: "expense", amount: 260, date: "2026-06-04", category: "Alimentación", subcategory: "Despensa", note: "Compra del supermercado", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-06-07", kind: "expense", amount: 120, date: "2026-06-07", category: "Transporte", subcategory: "Taxi/App", note: "Movilidad de la semana", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-06-10", kind: "expense", amount: 150, date: "2026-06-10", category: "Vivienda", subcategory: "Servicios", note: "Internet y luz", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-06-13", kind: "expense", amount: 150, date: "2026-06-13", category: "Alimentación", subcategory: "Restaurantes", note: "Almuerzo familiar", recurring: false, paymentSource: "BCP Crédito" },
  { id: "demo-2026-06-16", kind: "expense", amount: 220, date: "2026-06-16", category: "Alimentación", subcategory: "Despensa", note: "Compra semanal", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-06-19", kind: "expense", amount: 100, date: "2026-06-19", category: "Salud", subcategory: "Medicinas", note: "Farmacia", recurring: false, paymentSource: "Efectivo" },
  { id: "demo-2026-06-22", kind: "expense", amount: 180, date: "2026-06-22", category: "Transporte", subcategory: "Combustible", note: "Combustible", recurring: false, paymentSource: "BBVA Crédito" },
  { id: "demo-2026-06-24", kind: "expense", amount: 200, date: "2026-06-24", category: "Educación", subcategory: "Cursos", note: "Curso en línea", recurring: false, paymentSource: "BCP Crédito" },
  { id: "demo-2026-06-26", kind: "expense", amount: 170, date: "2026-06-26", category: "Entretenimiento", subcategory: "Salidas", note: "Salida con amigos", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-06-28", kind: "expense", amount: 180, date: "2026-06-28", category: "Otros", subcategory: "Ropa", note: "Ropa de invierno", recurring: false, paymentSource: "Interbank Crédito" },
  { id: "demo-2026-06-30", kind: "expense", amount: 320, date: "2026-06-30", category: "Entretenimiento", subcategory: "Viajes", note: "Escapada de fin de semana", recurring: false, paymentSource: "BCP Crédito" },

  { id: "demo-2026-07-income-1", kind: "income", amount: 4200, date: "2026-07-01", category: "Trabajo principal", subcategory: "Recurrente mensual", note: "Sueldo mensual", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-07-income-2", kind: "income", amount: 700, date: "2026-07-15", category: "Honorarios", subcategory: "Extraordinario", note: "Proyecto freelance", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-07-02", kind: "expense", amount: 1050, date: "2026-07-02", category: "Vivienda", subcategory: "Alquiler/Hipoteca", note: "Alquiler", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-07-05", kind: "expense", amount: 330, date: "2026-07-05", category: "Alimentación", subcategory: "Despensa", note: "Compra grande del mes", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-07-08", kind: "expense", amount: 180, date: "2026-07-08", category: "Transporte", subcategory: "Taxi/App", note: "Movilidad", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-07-11", kind: "expense", amount: 160, date: "2026-07-11", category: "Vivienda", subcategory: "Servicios", note: "Servicios del hogar", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-07-14", kind: "expense", amount: 220, date: "2026-07-14", category: "Alimentación", subcategory: "Restaurantes", note: "Cena especial", recurring: false, paymentSource: "BCP Crédito" },
  { id: "demo-2026-07-17", kind: "expense", amount: 260, date: "2026-07-17", category: "Alimentación", subcategory: "Despensa", note: "Compra semanal", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-07-20", kind: "expense", amount: 160, date: "2026-07-20", category: "Salud", subcategory: "Consultas", note: "Consulta médica", recurring: false, paymentSource: "Efectivo" },
  { id: "demo-2026-07-23", kind: "expense", amount: 350, date: "2026-07-23", category: "Educación", subcategory: "Cursos", note: "Taller profesional", recurring: false, paymentSource: "BCP Crédito" },
  { id: "demo-2026-07-25", kind: "expense", amount: 700, date: "2026-07-25", category: "Entretenimiento", subcategory: "Viajes", note: "Viaje por Fiestas Patrias", recurring: false, paymentSource: "BCP Crédito" },
  { id: "demo-2026-07-27", kind: "expense", amount: 280, date: "2026-07-27", category: "Entretenimiento", subcategory: "Salidas", note: "Paseo y actividades", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-07-29", kind: "expense", amount: 360, date: "2026-07-29", category: "Otros", subcategory: "Regalos", note: "Compras con tarjeta", recurring: false, paymentSource: "Interbank Crédito" },
  { id: "demo-2026-07-31", kind: "expense", amount: 250, date: "2026-07-31", category: "Otros", subcategory: "Imprevistos", note: "Reparación inesperada", recurring: false, paymentSource: "Efectivo" },

  { id: "demo-2026-08-income-1", kind: "income", amount: 4200, date: "2026-08-01", category: "Trabajo principal", subcategory: "Recurrente mensual", note: "Sueldo mensual", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-08-income-2", kind: "income", amount: 250, date: "2026-08-21", category: "Venta", subcategory: "Extraordinario", note: "Venta de un artículo", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-08-02", kind: "expense", amount: 1050, date: "2026-08-02", category: "Vivienda", subcategory: "Alquiler/Hipoteca", note: "Alquiler", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-08-05", kind: "expense", amount: 220, date: "2026-08-05", category: "Alimentación", subcategory: "Despensa", note: "Compra semanal", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-08-08", kind: "expense", amount: 70, date: "2026-08-08", category: "Transporte", subcategory: "Transporte público", note: "Pasajes", recurring: false, paymentSource: "Efectivo" },
  { id: "demo-2026-08-11", kind: "expense", amount: 140, date: "2026-08-11", category: "Vivienda", subcategory: "Servicios", note: "Internet y agua", recurring: true, paymentSource: "BCP Débito" },
  { id: "demo-2026-08-14", kind: "expense", amount: 80, date: "2026-08-14", category: "Alimentación", subcategory: "Restaurantes", note: "Almuerzo fuera", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-08-17", kind: "expense", amount: 160, date: "2026-08-17", category: "Alimentación", subcategory: "Despensa", note: "Compra semanal", recurring: false, paymentSource: "Interbank Débito" },
  { id: "demo-2026-08-20", kind: "expense", amount: 70, date: "2026-08-20", category: "Salud", subcategory: "Medicinas", note: "Farmacia", recurring: false, paymentSource: "Efectivo" },
  { id: "demo-2026-08-23", kind: "expense", amount: 60, date: "2026-08-23", category: "Transporte", subcategory: "Taxi/App", note: "Movilidad", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-08-25", kind: "expense", amount: 90, date: "2026-08-25", category: "Entretenimiento", subcategory: "Streaming", note: "Suscripciones", recurring: true, paymentSource: "BCP Crédito" },
  { id: "demo-2026-08-27", kind: "expense", amount: 80, date: "2026-08-27", category: "Educación", subcategory: "Libros/Materiales", note: "Libro", recurring: false, paymentSource: "Yape" },
  { id: "demo-2026-08-29", kind: "expense", amount: 100, date: "2026-08-29", category: "Otros", subcategory: "Mascotas", note: "Alimento para mascota", recurring: false, paymentSource: "Efectivo" },
  { id: "demo-2026-08-31", kind: "expense", amount: 80, date: "2026-08-31", category: "Alimentación", subcategory: "Delivery", note: "Cena por delivery", recurring: false, paymentSource: "Yape" },
];

const money = (value: number) => new Intl.NumberFormat("es-PE", { style: "currency", currency: "PEN", maximumFractionDigits: 0 }).format(value);
const read = <T,>(key: string, fallback: T): T => { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; } catch { return fallback; } };
const dateLabel = (date: string) => new Intl.DateTimeFormat("es-PE", { day: "numeric", month: "long" }).format(new Date(`${date}T12:00:00`));
const normalize = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
const localISODate = (offset = 0) => { const date = new Date(); date.setDate(date.getDate() + offset); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; };
const toISODate = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const parseISODate = (value: string) => new Date(`${value}T12:00:00`);
const capitalize = (value: string) => value.charAt(0).toUpperCase() + value.slice(1);
const getCategoryAppearance = (category: string, appearances: CategoryAppearances, index = 0): CategoryAppearance => appearances[category] ?? { icon: "shopping", color: CATEGORY_COLOR_CHOICES[index % CATEGORY_COLOR_CHOICES.length] };
const withDefaultAppearances = (categories: Categories, saved: CategoryAppearances) => Object.fromEntries(Object.keys(categories).map((category, index) => [category, saved[category] ?? DEFAULT_CATEGORY_APPEARANCES[category] ?? getCategoryAppearance(category, {}, index)]));

function CategoryIcon({ category, appearances, size = "md" }: { category: string; appearances: CategoryAppearances; size?: "sm" | "md" | "lg" }) {
  const appearance = getCategoryAppearance(category, appearances);
  const Icon = CATEGORY_ICONS[appearance.icon] ?? ShoppingBag;
  return <span className={`grid shrink-0 place-items-center rounded-xl ${size === "sm" ? "size-8" : size === "lg" ? "size-12" : "size-10"}`} style={{ color: appearance.color, backgroundColor: `${appearance.color}20` }}><Icon className={size === "sm" ? "size-4" : size === "lg" ? "size-6" : "size-5"}/></span>;
}

function monthlyDate(first: string, offset: number) {
  const date = parseISODate(first);
  const target = new Date(date.getFullYear(), date.getMonth() + offset, 1, 12);
  target.setDate(Math.min(date.getDate(), new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate()));
  return toISODate(target);
}
function loanSchedule(loan: Loan, extra = 0, after = 0, strategy: "term" | "payment" = "term") {
  const months = Math.min(360, Math.max(1, Math.round(loan.months)));
  const first = loan.firstPaymentDate || monthlyDate(loan.startDate, 1);
  const dates = Array.from({ length: months }, (_, index) => monthlyDate(first, index));
  const yearRate = 1 + Math.max(0, loan.tcea) / 100;
  const days = (from: string, to: string) => Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000);
  const rate = (from: string, to: string) => Math.pow(yearRate, Math.max(0, days(from, to)) / 365) - 1;
  const fixedPayment = (balance: number, start: string, remaining: string[]) => balance / remaining.reduce((sum, date) => sum + 1 / Math.pow(yearRate, Math.max(0, days(start, date)) / 365), 0);
  let balance = loan.principal, payment = fixedPayment(balance, loan.startDate, dates), previous = loan.startDate;
  const rows: { number: number; date: string; payment: number; principal: number; interest: number; balance: number; extra: number }[] = [];
  const applyExtra = (index: number, date: string) => {
    const applied = Math.min(Math.max(0, extra), balance); balance -= applied;
    if (strategy === "payment" && balance > 0) payment = fixedPayment(balance, date, dates.slice(index));
    return applied;
  };
  if (after === 0 && extra > 0) applyExtra(0, loan.startDate);
  for (let index = 0; index < months && balance > 0.005; index++) {
    const interest = balance * rate(previous, dates[index]);
    const capital = index === months - 1 ? balance : Math.min(balance, Math.max(0, payment - interest));
    const paid = capital + interest; balance = Math.max(0, balance - capital);
    const applied = extra > 0 && index + 1 === after ? applyExtra(index + 1, dates[index]) : 0;
    rows.push({ number: index + 1, date: dates[index], payment: paid, principal: capital, interest, balance, extra: applied });
    previous = dates[index];
  }
  return rows;
}

function periodBounds(anchor: string, mode: PeriodMode) {
  const date = parseISODate(anchor);
  if (mode === "week") {
    const start = new Date(date); const weekday = (start.getDay() + 6) % 7; start.setDate(start.getDate() - weekday);
    const end = new Date(start); end.setDate(end.getDate() + 6);
    return { start: toISODate(start), end: toISODate(end) };
  }
  if (mode === "year") return { start: `${date.getFullYear()}-01-01`, end: `${date.getFullYear()}-12-31` };
  return { start: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-01`, end: toISODate(new Date(date.getFullYear(), date.getMonth() + 1, 0, 12)) };
}

function shiftAnchor(anchor: string, mode: PeriodMode, amount: number) {
  const date = parseISODate(anchor);
  if (mode === "week") date.setDate(date.getDate() + amount * 7);
  else if (mode === "month") date.setMonth(date.getMonth() + amount);
  else date.setFullYear(date.getFullYear() + amount);
  return toISODate(date);
}

function periodName(anchor: string, mode: PeriodMode) {
  const date = parseISODate(anchor); const format = new Intl.DateTimeFormat("es-PE", mode === "year" ? { year: "numeric" } : { month: "long", year: "numeric" });
  if (mode === "week") { const { start, end } = periodBounds(anchor, mode); return `${dateLabel(start)} – ${dateLabel(end)} de ${parseISODate(end).getFullYear()}`; }
  return capitalize(format.format(date));
}

function parseQuickExpense(text: string, categories: Categories, paymentMethods: string[]): Entry | null {
  const clean = normalize(text.trim());
  const amountMatch = clean.match(/(?:s\/?\s*)?(\d+(?:[.,]\d{1,2})?)/);
  if (!amountMatch) return null;
  const amount = Number(amountMatch[1].replace(",", "."));
  if (!Number.isFinite(amount) || amount <= 0) return null;
  const rules = [
    { terms: ["alquiler", "renta", "hipoteca"], category: "Vivienda", subcategory: "Alquiler/Hipoteca" },
    { terms: ["luz", "agua", "internet", "telefono", "servicio"], category: "Vivienda", subcategory: "Servicios" },
    { terms: ["taxi", "uber", "cabify", "indrive"], category: "Transporte", subcategory: "Taxi/App" },
    { terms: ["pasaje", "bus", "combi", "metro", "corredor"], category: "Transporte", subcategory: "Transporte público" },
    { terms: ["gasolina", "combustible"], category: "Transporte", subcategory: "Combustible" },
    { terms: ["mercado", "supermercado", "despensa", "abarrotes"], category: "Alimentación", subcategory: "Despensa" },
    { terms: ["delivery", "pedido", "rappi", "pedidos ya"], category: "Alimentación", subcategory: "Delivery" },
    { terms: ["desayuno", "almuerzo", "cena", "restaurante", "comida"], category: "Alimentación", subcategory: "Restaurantes" },
    { terms: ["farmacia", "medicina", "medicamento"], category: "Salud", subcategory: "Medicinas" },
    { terms: ["doctor", "consulta", "clinica"], category: "Salud", subcategory: "Consultas" },
    { terms: ["netflix", "spotify", "streaming", "disney"], category: "Entretenimiento", subcategory: "Streaming" },
    { terms: ["cine", "salida", "fiesta"], category: "Entretenimiento", subcategory: "Salidas" },
    { terms: ["curso", "clase"], category: "Educación", subcategory: "Cursos" },
    { terms: ["libro", "material"], category: "Educación", subcategory: "Libros/Materiales" },
    { terms: ["inversion", "inverti", "acciones", "fondo mutuo"], category: "Ahorro e inversión", subcategory: "Inversiones" },
    { terms: ["ahorro", "emergencia"], category: "Ahorro e inversión", subcategory: "Fondo de emergencia" },
  ];
  const rule = rules.find((item) => item.terms.some((term) => clean.includes(term)) && categories[item.category]);
  let category = rule?.category ?? "Otros";
  let subcategory = rule?.subcategory ?? categories[category]?.[0] ?? "General";
  if (!rule) {
    for (const [candidate, subs] of Object.entries(categories)) {
      const matchedSub = subs.find((sub) => clean.includes(normalize(sub)));
      if (matchedSub || clean.includes(normalize(candidate))) { category = candidate; subcategory = matchedSub ?? subs[0] ?? "General"; break; }
    }
  }
  const mentionedBank = ["bcp", "interbank", "bbva", "scotiabank"].find((bank) => clean.includes(bank));
  const mentionedType = clean.includes("credito") || clean.includes("tarjeta") ? "credito" : clean.includes("debito") ? "debito" : null;
  const bankSource = mentionedBank
    ? paymentMethods.find((method) => {
      const normalizedMethod = normalize(method);
      return normalizedMethod.includes(mentionedBank) && (!mentionedType || normalizedMethod.includes(mentionedType));
    })
    : undefined;
  const source = paymentMethods.find((method) => clean.includes(normalize(method)))
    ?? bankSource
    ?? paymentMethods.find((method) => clean.includes("yape") && normalize(method) === "yape")
    ?? paymentMethods.find((method) => clean.includes("plin") && normalize(method) === "plin")
    ?? paymentMethods.find((method) => clean.includes("efectivo") && normalize(method) === "efectivo")
    ?? "No especificado";
  return { id: "", kind: "expense", amount, date: clean.includes("ayer") ? localISODate(-1) : localISODate(), category, subcategory, note: text.trim(), recurring: false, paymentSource: source };
}

export default function Page() {
  const [entries, setEntries] = useState<Entry[]>(SEED);
  const [budgets, setBudgets] = useState<Record<string, number>>(DEFAULT_BUDGETS);
  const [categories, setCategories] = useState<Categories>(DEFAULT_CATEGORIES);
  const [categoryAppearances, setCategoryAppearances] = useState<CategoryAppearances>(DEFAULT_CATEGORY_APPEARANCES);
  const [paymentMethods, setPaymentMethods] = useState<string[]>(DEFAULT_PAYMENT_METHODS);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>("home");
  const [periodMode, setPeriodMode] = useState<PeriodMode>("month");
  const [periodAnchor, setPeriodAnchor] = useState(localISODate());
  const [filter, setFilter] = useState<"all" | Kind>("all");
  const [entryDraft, setEntryDraft] = useState<Entry | null>(null);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [paymentMethodsOpen, setPaymentMethodsOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Entry | null>(null);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [importPreview, setImportPreview] = useState<ImportPreview | null>(null);
  const [backupMessage, setBackupMessage] = useState("");

  useEffect(() => {
    const savedEntries = read<Entry[]>("mis-cuentas.entries", SEED).map((item) => ({ ...item, paymentSource: item.paymentSource || "No especificado" }));
    const demoHistoryWasInjected = localStorage.getItem("mis-cuentas.demoHistoryInjected.v1") === "true";
    if (demoHistoryWasInjected) {
      setEntries(savedEntries);
    } else {
      const savedIds = new Set(savedEntries.map((item) => item.id));
      setEntries([...DEMO_HISTORY.filter((item) => !savedIds.has(item.id)), ...savedEntries]);
      localStorage.setItem("mis-cuentas.demoHistoryInjected.v1", "true");
    }
    const savedCategories = read("mis-cuentas.categories", DEFAULT_CATEGORIES);
    if (!savedCategories["Ahorro e inversión"]) savedCategories["Ahorro e inversión"] = DEFAULT_CATEGORIES["Ahorro e inversión"];
    setCategories(savedCategories);
    setCategoryAppearances(withDefaultAppearances(savedCategories, read("mis-cuentas.categoryAppearances", DEFAULT_CATEGORY_APPEARANCES)));
    const savedBudgets = read("mis-cuentas.budgets", DEFAULT_BUDGETS);
    if (savedBudgets["Ahorro e inversión"] == null) savedBudgets["Ahorro e inversión"] = DEFAULT_BUDGETS["Ahorro e inversión"];
    setBudgets(savedBudgets);
    setPaymentMethods(read("mis-cuentas.paymentMethods", DEFAULT_PAYMENT_METHODS));
    setLoans(read("mis-cuentas.loans", []));
    setReady(true);
  }, []);
  useEffect(() => { if (ready) localStorage.setItem("mis-cuentas.entries", JSON.stringify(entries)); }, [entries, ready]);
  useEffect(() => { if (ready) localStorage.setItem("mis-cuentas.budgets", JSON.stringify(budgets)); }, [budgets, ready]);
  useEffect(() => { if (ready) localStorage.setItem("mis-cuentas.categories", JSON.stringify(categories)); }, [categories, ready]);
  useEffect(() => { if (ready) localStorage.setItem("mis-cuentas.categoryAppearances", JSON.stringify(categoryAppearances)); }, [categoryAppearances, ready]);
  useEffect(() => { if (ready) localStorage.setItem("mis-cuentas.paymentMethods", JSON.stringify(paymentMethods)); }, [paymentMethods, ready]);
  useEffect(() => { if (ready) localStorage.setItem("mis-cuentas.loans", JSON.stringify(loans)); }, [loans, ready]);

  const bounds = periodBounds(periodAnchor, periodMode);
  const periodLabel = periodName(periodAnchor, periodMode);
  const periodEntries = entries.filter((item) => item.date >= bounds.start && item.date <= bounds.end);
  const expenses = periodEntries.filter((item) => item.kind === "expense");
  const incomes = periodEntries.filter((item) => item.kind === "income");
  const spent = expenses.reduce((sum, item) => sum + item.amount, 0);
  const earned = incomes.reduce((sum, item) => sum + item.amount, 0);
  const budgetTotal = Object.values(budgets).reduce((sum, value) => sum + value, 0);
  const selectedDate = parseISODate(periodAnchor);
  const daysInSelectedMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();
  const budgetFactor = periodMode === "week" ? 7 / daysInSelectedMonth : periodMode === "year" ? 12 : 1;
  const effectiveBudget = budgetTotal * budgetFactor;
  const remaining = Math.max(0, effectiveBudget - spent);
  const totalDays = Math.round((parseISODate(bounds.end).getTime() - parseISODate(bounds.start).getTime()) / 86400000) + 1;
  const today = localISODate(); const inCurrentPeriod = today >= bounds.start && today <= bounds.end;
  const elapsedDays = inCurrentPeriod ? Math.max(1, Math.round((parseISODate(today).getTime() - parseISODate(bounds.start).getTime()) / 86400000) + 1) : totalDays;
  const projected = Math.round(spent / elapsedDays * totalDays);
  const projectionDelta = projected - effectiveBudget;
  const previousAnchor = shiftAnchor(periodAnchor, periodMode, -1); const previousBounds = periodBounds(previousAnchor, periodMode);
  const previousEntries = entries.filter((item) => item.date >= previousBounds.start && item.date <= previousBounds.end);
  const previousSpent = previousEntries.filter((item) => item.kind === "expense").reduce((sum, item) => sum + item.amount, 0);
  const previousEarned = previousEntries.filter((item) => item.kind === "income").reduce((sum, item) => sum + item.amount, 0);
  const categoryData = Object.keys(categories).map((category, index) => ({
    category,
    value: expenses.filter((item) => item.category === category).reduce((sum, item) => sum + item.amount, 0),
    budget: (budgets[category] ?? 0) * budgetFactor,
    ...getCategoryAppearance(category, categoryAppearances, index),
  }));
  const trendData = periodMode === "year"
    ? Array.from({ length: 12 }, (_, index) => { const key = `${selectedDate.getFullYear()}-${String(index + 1).padStart(2, "0")}`; return { date: `${key}-01`, day: new Intl.DateTimeFormat("es-PE", { month: "short" }).format(new Date(selectedDate.getFullYear(), index, 1)).slice(0, 3), amount: entries.filter((item) => item.kind === "expense" && item.date.startsWith(key)).reduce((sum, item) => sum + item.amount, 0) }; })
    : Array.from({ length: totalDays }, (_, index) => { const day = parseISODate(bounds.start); day.setDate(day.getDate() + index); const date = toISODate(day); return { date, day: periodMode === "week" ? new Intl.DateTimeFormat("es-PE", { weekday: "short" }).format(day).slice(0, 2) : String(day.getDate()), amount: expenses.filter((item) => item.date === date).reduce((sum, item) => sum + item.amount, 0) }; });
  const annualData = Array.from({ length: 12 }, (_, index) => { const key = `${selectedDate.getFullYear()}-${String(index + 1).padStart(2, "0")}`; const monthItems = entries.filter((item) => item.date.startsWith(key)); return { month: capitalize(new Intl.DateTimeFormat("es-PE", { month: "short" }).format(new Date(selectedDate.getFullYear(), index, 1)).replace(".", "")), income: monthItems.filter((item) => item.kind === "income").reduce((sum, item) => sum + item.amount, 0), expense: monthItems.filter((item) => item.kind === "expense").reduce((sum, item) => sum + item.amount, 0) }; });
  const selectedDayEntries = selectedDay ? expenses.filter((item) => item.date === selectedDay) : [];
  const selectedCategoryEntries = selectedCategory ? expenses.filter((item) => item.category === selectedCategory) : [];
  const paymentData = Array.from(new Set([...paymentMethods, "No especificado"])).map((method) => ({ method, value: expenses.filter((item) => item.paymentSource === method).reduce((sum, item) => sum + item.amount, 0) })).filter((item) => item.value > 0).sort((a, b) => b.value - a.value);

  const openEntry = (kind: Kind, existing?: Entry) => setEntryDraft(existing ?? {
    id: "", kind, amount: 0, date: localISODate(),
    category: kind === "income" ? "Trabajo principal" : Object.keys(categories)[0] ?? "Otros",
    subcategory: kind === "income" ? "Extraordinario" : Object.values(categories)[0]?.[0] ?? "General",
    note: "", recurring: false, paymentSource: kind === "income" ? paymentMethods[0] ?? "No especificado" : "No especificado",
  });
  const saveEntry = (entry: Entry) => {
    setEntries((current) => entry.id ? current.map((item) => item.id === entry.id ? entry : item) : [{ ...entry, id: crypto.randomUUID() }, ...current]);
    setEntryDraft(null);
  };

  return <main style={{ height: "100vh", maxHeight: "100dvh" }} className="h-screen max-h-screen overflow-hidden bg-[#e9e4d8] text-[#173c3a]">
    <div style={{ height: "100%", display: "grid", gridTemplateRows: "auto auto minmax(0, 1fr) auto" }} className="mx-auto w-full max-w-6xl overflow-hidden bg-[#f5f0e5] shadow-2xl">
      <Header spent={spent} budget={effectiveBudget} remaining={remaining} periodLabel={periodLabel} totalDays={totalDays} />
      <PeriodSelector mode={periodMode} anchor={periodAnchor} label={periodLabel} onMode={setPeriodMode} onShift={(amount) => setPeriodAnchor(shiftAnchor(periodAnchor, periodMode, amount))} onToday={() => setPeriodAnchor(localISODate())}/>
      <div className="mx-auto min-h-0 w-full max-w-5xl flex-1 overflow-y-auto px-4 pb-8 pt-6 sm:px-8">
        {tab === "home" && <HomeView earned={earned} spent={spent} budget={effectiveBudget} projected={projected} projectionDelta={projectionDelta} categoryData={categoryData} categoryAppearances={categoryAppearances} dailyData={trendData} paymentData={paymentData} periodLabel={periodLabel} periodMode={periodMode} onDaySelect={(date: string) => periodMode !== "year" && setSelectedDay(date)} onCategorySelect={setSelectedCategory} onQuickExpense={(text: string) => { const parsed = parseQuickExpense(text, categories, paymentMethods); if (parsed) setEntryDraft(parsed); return Boolean(parsed); }} onProgress={() => setTab("progress")} />}
        {tab === "movements" && <Movements entries={periodEntries} periodLabel={periodLabel} filter={filter} setFilter={setFilter} categoryAppearances={categoryAppearances} onNew={openEntry} onEdit={(entry) => openEntry(entry.kind, entry)} onDelete={setDeleteTarget} />}
        {tab === "plan" && <PlanView incomes={incomes} spent={spent} periodLabel={periodLabel} budgets={budgets} categoryData={categoryData} entries={entries} categories={categories} categoryAppearances={categoryAppearances} paymentMethods={paymentMethods} paymentData={paymentData} backupMessage={backupMessage} onBackupMessage={setBackupMessage} onImportPreview={setImportPreview} onNewIncome={() => openEntry("income")} onBudgets={() => setBudgetOpen(true)} onCategories={() => setCategoryOpen(true)} onPaymentMethods={() => setPaymentMethodsOpen(true)} />}
        {tab === "progress" && <ProgressView projected={projected} budget={effectiveBudget} categoryData={categoryData} entries={periodEntries} annualData={annualData} periodLabel={periodLabel} periodMode={periodMode} earned={earned} spent={spent} previousEarned={previousEarned} previousSpent={previousSpent} onPlan={() => setTab("plan")} />}
        {tab === "loans" && <LoansView loans={loans} onSave={(loan: Loan) => setLoans((current) => current.some((item) => item.id === loan.id) ? current.map((item) => item.id === loan.id ? loan : item) : [...current, { ...loan, id: loan.id || crypto.randomUUID() }])} onDelete={(id: string) => setLoans((current) => current.filter((item) => item.id !== id))} />}
      </div>
      <BottomNav tab={tab} setTab={setTab} />
    </div>
    <EntrySheet draft={entryDraft} categories={categories} paymentMethods={paymentMethods} onClose={() => setEntryDraft(null)} onSave={saveEntry} />
    <BudgetSheet open={budgetOpen} budgets={budgets} categories={categories} monthlyIncome={periodMode === "year" ? earned / 12 : periodMode === "week" ? earned * 4.345 : earned} onClose={() => setBudgetOpen(false)} onSave={(next) => { setBudgets(next); setBudgetOpen(false); }} />
    <CategorySheet open={categoryOpen} categories={categories} appearances={categoryAppearances} onClose={() => setCategoryOpen(false)} onSave={(next, nextAppearances) => { setCategories(next); setCategoryAppearances(nextAppearances); setBudgets((current) => Object.fromEntries(Object.keys(next).map((key) => [key, current[key] ?? 0]))); setCategoryOpen(false); }} />
    <PaymentMethodsSheet open={paymentMethodsOpen} methods={paymentMethods} onClose={() => setPaymentMethodsOpen(false)} onSave={(next) => { setPaymentMethods(next); setPaymentMethodsOpen(false); }} />
    <DayDetailDialog date={selectedDay} entries={selectedDayEntries} categories={categoryData} appearances={categoryAppearances} onClose={() => setSelectedDay(null)} onViewMovements={() => { setSelectedDay(null); setFilter("expense"); setTab("movements"); }} />
    <CategoryDetailDialog category={selectedCategory} entries={selectedCategoryEntries} periodLabel={periodLabel} appearances={categoryAppearances} color={categoryData.find((item) => item.category === selectedCategory)?.color ?? "#2f6b65"} onClose={() => setSelectedCategory(null)} onViewMovements={() => { setSelectedCategory(null); setFilter("expense"); setTab("movements"); }} />
    <AlertDialog open={Boolean(importPreview)} onOpenChange={(open) => !open && setImportPreview(null)}>
      <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Importar este respaldo?</AlertDialogTitle><AlertDialogDescription>Se reemplazarán los datos actuales por {importPreview?.entries.length ?? 0} movimientos, {Object.keys(importPreview?.budgets ?? {}).length} presupuestos y {Object.keys(importPreview?.categories ?? {}).length} categorías de “{importPreview?.fileName}”.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-[#2f6b65] hover:bg-[#275b56]" onClick={() => { if (!importPreview) return; setEntries(importPreview.entries); setBudgets(importPreview.budgets); setCategories(importPreview.categories); setCategoryAppearances(importPreview.categoryAppearances); setPaymentMethods(importPreview.paymentMethods); setBackupMessage("Respaldo importado correctamente."); setImportPreview(null); }}>Reemplazar e importar</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
    </AlertDialog>
    <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
      <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Eliminar este movimiento?</AlertDialogTitle><AlertDialogDescription>Se retirará de tus resúmenes y gráficos guardados en este dispositivo.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-[#b95f4d] hover:bg-[#a44f40]" onClick={() => { setEntries((current) => current.filter((item) => item.id !== deleteTarget?.id)); setDeleteTarget(null); }}>Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
    </AlertDialog>
  </main>;
}

function Header({ spent, budget, remaining, periodLabel, totalDays }: { spent: number; budget: number; remaining: number; periodLabel: string; totalDays: number }) {
  const used = budget ? Math.min(100, spent / budget * 100) : 0;
  return <header className="bg-[radial-gradient(circle_at_90%_5%,rgba(255,255,255,.12)_0_72px,transparent_73px),linear-gradient(135deg,#173f3d,#2d6862)] px-5 pb-6 pt-5 text-[#fffaf0] sm:px-8">
    <p className="font-mono text-xs tracking-[.16em] text-white/70">{periodLabel.toUpperCase()}</p><h1 className="font-serif text-3xl font-semibold">Mis Cuentas</h1>
    <div className="mt-7 grid gap-4 sm:grid-cols-2"><div><p className="text-sm text-white/75">Disponible del presupuesto del período</p><p className="font-mono text-4xl">{money(remaining)}</p><p className="mt-2 text-sm text-white/80">Referencia aproximada: {money(remaining / Math.max(1, totalDays))} por día.</p></div><div className="rounded-2xl bg-black/10 p-4"><div className="flex justify-between text-xs"><span>Presupuesto utilizado</span><span>{Math.round(used)}%</span></div><Progress value={used} className="mt-2 h-2 bg-white/15 [&>div]:bg-[#e2b453]"/><div className="mt-2 flex justify-between font-mono text-xs"><span>{money(spent)} gastados</span><span>{money(budget)} planificados</span></div></div></div>
  </header>;
}

function PeriodSelector({ mode, anchor, label, onMode, onShift, onToday }: { mode: PeriodMode; anchor: string; label: string; onMode: (mode: PeriodMode) => void; onShift: (amount: number) => void; onToday: () => void }) {
  const isCurrent = periodBounds(anchor, mode).start <= localISODate() && periodBounds(anchor, mode).end >= localISODate();
  return <section className="z-10 shrink-0 border-b border-[#d8cdae] bg-[#fffdf8]/95 px-4 py-3 shadow-sm backdrop-blur sm:px-8"><div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-1"><Button variant="ghost" size="icon" onClick={() => onShift(-1)} aria-label="Período anterior"><ArrowLeft className="size-4"/></Button><div className="min-w-48 text-center"><p className="flex items-center justify-center gap-2 text-sm font-semibold"><CalendarRange className="size-4 text-[#2f6b65]"/>{label}</p>{!isCurrent && <button onClick={onToday} className="text-xs text-[#2f6b65] underline">Volver al período actual</button>}</div><Button variant="ghost" size="icon" onClick={() => onShift(1)} aria-label="Período siguiente"><ArrowRight className="size-4"/></Button></div><div className="grid grid-cols-3 rounded-xl bg-[#eee7d8] p-1">{(["week","month","year"] as PeriodMode[]).map((item) => <button key={item} onClick={() => onMode(item)} className={`rounded-lg px-3 py-2 text-xs font-semibold ${mode === item ? "bg-[#173c3a] text-white shadow-sm" : "text-[#51655f]"}`}>{item === "week" ? "Semana" : item === "month" ? "Mes" : "Año"}</button>)}</div></div></section>;
}

function HomeView({ earned, spent, budget, projected, projectionDelta, categoryData, categoryAppearances, dailyData, paymentData, periodLabel, periodMode, onDaySelect, onCategorySelect, onQuickExpense, onProgress }: any) {
  const used = categoryData.filter((item: any) => item.value > 0);
  const peak = dailyData.reduce((best: any, item: any) => item.amount > best.amount ? item : best, dailyData[0] ?? { amount: 0, date: localISODate() });
  const opportunity = categoryData.slice().sort((a: any, b: any) => (b.value - b.budget) - (a.value - a.budget))[0];
  return <div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
    <div className="grid content-start gap-5">
      <div className="grid grid-cols-2 gap-3"><Metric label={`Ingresos · ${periodLabel}`} value={money(earned)} detail="Sueldo e ingresos extraordinarios" /><Metric label="Saldo del período" value={money(earned - spent)} detail="Ingresos menos gastos registrados" /></div>
      <QuickEntry onSubmit={onQuickExpense}/>
      <Panel title={periodMode === "year" ? "Gasto por mes" : "Gasto diario"} subtitle={`${periodLabel}${periodMode === "year" ? "" : " · toca una barra para ver el detalle"}`}><div className="h-52"><ResponsiveContainer><BarChart data={dailyData}><XAxis dataKey="day" axisLine={false} tickLine={false} interval={periodMode === "month" ? 4 : 0}/><Tooltip labelFormatter={(_, payload) => payload?.[0]?.payload?.date ? (periodMode === "year" ? payload[0].payload.day : dateLabel(payload[0].payload.date)) : ""} formatter={(value: number) => [money(value), "Gasto"]} /><Bar dataKey="amount" radius={[8,8,2,2]} cursor={periodMode === "year" ? "default" : "pointer"} onClick={(point: any) => onDaySelect(point?.payload?.date ?? point?.date)}>{dailyData.map((item: any) => <Cell key={item.date} fill={item.date === peak.date ? "#b95f4d" : "#2f6b65"}/>)}</Bar></BarChart></ResponsiveContainer></div><p className="text-sm text-[#687771]">Mayor gasto del período: <b className="text-[#173c3a]">{periodMode === "year" ? peak.day : dateLabel(peak.date)}, {money(peak.amount)}</b>.</p></Panel>
      <button onClick={onProgress} className="flex items-center gap-3 rounded-2xl border border-[#d8cdae] bg-[#fffdf8] p-4 text-left shadow-sm"><span className="rounded-xl bg-[#e1eee8] p-2 text-[#2f6b65]"><Sparkles className="size-5"/></span><span className="flex-1"><b className="block text-sm">Lectura rápida del período</b><span className="text-xs text-[#687771]">{opportunity?.value > opportunity?.budget ? `${opportunity.category} supera su referencia por ${money(opportunity.value - opportunity.budget)}.` : "Tus categorías se mantienen dentro del presupuesto de referencia."}</span></span><ChevronRight className="size-5"/></button>
    </div>
    <div className="grid content-start gap-5">
      <Panel title={`Gastos por categoría · ${periodLabel}`} subtitle={`Total registrado: ${money(spent)} · toca una categoría`}><div className="h-52"><ResponsiveContainer><PieChart><Pie data={used} dataKey="value" nameKey="category" innerRadius={52} outerRadius={78} paddingAngle={3} cursor="pointer" onClick={(point: any) => onCategorySelect(point?.payload?.category ?? point?.category)}>{used.map((item: any) => <Cell key={item.category} fill={item.color}/>)}</Pie><Tooltip formatter={(value: number) => money(value)}/></PieChart></ResponsiveContainer></div>{used.length ? <div className="space-y-1 border-t border-[#e5dcc8] pt-3">{used.map((item: any) => <button key={item.category} onClick={() => onCategorySelect(item.category)} className="flex w-full items-center gap-2 rounded-xl px-1 py-1.5 text-left text-sm hover:bg-[#f1eadb]"><CategoryIcon category={item.category} appearances={categoryAppearances} size="sm"/><span className="flex-1">{item.category}</span><b className="font-mono">{money(item.value)}</b><ChevronRight className="size-4 text-[#88928e]"/></button>)}</div> : <p className="text-sm text-[#687771]">No hay gastos en este período.</p>}</Panel>
      <Panel title="Cómo pagaste" subtitle={`Gastos de ${periodLabel} por medio de pago`}><div className="space-y-3">{paymentData.length ? paymentData.map((item: any) => <div key={item.method} className="flex items-center gap-3"><span className="rounded-lg bg-[#e1eee8] p-2 text-[#2f6b65]"><CreditCard className="size-4"/></span><span className="flex-1 text-sm">{item.method}</span><b className="font-mono text-sm">{money(item.value)}</b></div>) : <p className="text-sm text-[#687771]">No hay gastos en este período.</p>}</div></Panel>
      <Panel title="Proyección del período" subtitle="Estimación según el ritmo registrado"><p className="font-serif text-3xl">{money(projected)}</p><p className="mt-2 text-sm leading-6 text-[#687771]">Si mantienes el mismo ritmo, este sería tu gasto al finalizar el período. Es una referencia, no un cobro ni una meta.</p><div className="mt-4 grid grid-cols-2 gap-2 rounded-xl bg-[#eee7d8] p-3 text-xs"><span><b className="block text-base text-[#173c3a]">{money(budget)}</b>Presupuesto</span><span><b className={`block text-base ${projectionDelta > 0 ? "text-[#b95f4d]" : "text-[#4e7e63]"}`}>{projectionDelta > 0 ? "+" : ""}{money(projectionDelta)}</b>Diferencia estimada</span></div></Panel>
    </div>
  </div>;
}

function Movements({ entries, periodLabel, filter, setFilter, categoryAppearances, onNew, onEdit, onDelete }: any) {
  const visible = entries.filter((item: Entry) => filter === "all" || item.kind === filter).sort((a: Entry,b: Entry) => b.date.localeCompare(a.date));
  return <><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-serif text-2xl">Movimientos</h2><p className="text-sm text-[#687771]">Gastos e ingresos de {periodLabel}.</p></div><div className="flex gap-2"><Button variant="outline" onClick={() => onNew("income")}><ArrowDownLeft/>Ingreso</Button><Button className="bg-[#2f6b65] text-white" onClick={() => onNew("expense")}><Plus/>Gasto</Button></div></div><div className="mt-5 flex gap-2">{[["all","Todos"],["expense","Gastos"],["income","Ingresos"]].map(([value,label]) => <Button key={value} variant={filter === value ? "default" : "outline"} onClick={() => setFilter(value)} className={filter === value ? "bg-[#173c3a] text-white" : ""}>{label}</Button>)}</div><div className="mt-4 space-y-2">{visible.length ? visible.map((item: Entry) => { const appearance = item.kind === "expense" ? getCategoryAppearance(item.category, categoryAppearances) : { color: "#4e7e63", icon: "money" as CategoryIconKey }; return <div key={item.id} className="group flex items-center gap-3 rounded-2xl border p-3 shadow-sm sm:p-4" style={{ borderColor: `${appearance.color}55`, background: `linear-gradient(90deg, ${appearance.color}18, #fffdf8 34%)` }}>{item.kind === "income" ? <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-[#e1eee8] text-[#4e7e63]"><ArrowDownLeft className="size-5"/></span> : <CategoryIcon category={item.category} appearances={categoryAppearances}/>}<span className="min-w-0 flex-1"><b className="block truncate text-sm">{item.note || item.category}</b><small className="block truncate text-[#687771]">{item.category} · {item.subcategory}</small><small className="block truncate text-[#87908d]">{item.paymentSource || "No especificado"} · {item.date}</small></span><span className={`shrink-0 font-mono text-sm font-semibold ${item.kind === "income" ? "text-[#4e7e63]" : ""}`}>{item.kind === "income" ? "+" : "−"}{money(item.amount)}</span><div className="flex shrink-0"><Button variant="ghost" size="icon" onClick={() => onEdit(item)} aria-label="Editar"><Pencil className="size-4"/></Button><Button variant="ghost" size="icon" onClick={() => onDelete(item)} aria-label="Eliminar"><Trash2 className="size-4 text-[#b95f4d]"/></Button></div></div>; }) : <p className="rounded-2xl border border-[#d8cdae] bg-[#fffdf8] p-8 text-center text-sm text-[#687771]">No hay movimientos en este período.</p>}</div></>;
}

function PlanView({ incomes, spent, periodLabel, budgets, categoryData, entries, categories, categoryAppearances, paymentMethods, paymentData, backupMessage, onBackupMessage, onImportPreview, onNewIncome, onBudgets, onCategories, onPaymentMethods }: any) {
  const total = Object.values(budgets as Record<string, number>).reduce((sum, value) => sum + value, 0);
  return <div className="grid gap-5 lg:grid-cols-2"><div className="grid content-start gap-5"><Panel title={`Ingresos · ${periodLabel}`} action={<Button variant="link" onClick={onNewIncome} className="p-0 text-[#2f6b65]">Agregar ingreso</Button>}>{incomes.length ? incomes.map((item: Entry) => <div key={item.id} className="flex justify-between border-b border-[#e5dcc8] py-3 last:border-0"><span><b className="text-sm">{item.note}</b><small className="block text-[#687771]">{item.recurring ? "Recurrente y editable" : "Extraordinario"}</small></span><b className="font-mono text-[#4e7e63]">+{money(item.amount)}</b></div>) : <p className="text-sm text-[#687771]">No hay ingresos en este período.</p>}</Panel><Panel title="Categorías y subcategorías" subtitle="Personaliza las opciones que aparecen al registrar un gasto" action={<Button variant="outline" onClick={onCategories}><Settings2/>Administrar</Button>}><p className="text-sm leading-6 text-[#687771]">Incluye una sección de ahorro e inversión para separar el dinero destinado a tu futuro.</p></Panel><Panel title="Medios de pago" subtitle="Identifica desde dónde salió el dinero" action={<Button variant="outline" onClick={onPaymentMethods}><Settings2/>Administrar</Button>}><div className="flex flex-wrap gap-2">{paymentMethods.slice(0,6).map((method: string) => <span key={method} className="rounded-full bg-[#eee7d8] px-3 py-1.5 text-xs">{method}</span>)}</div>{paymentData.length > 0 && <p className="mt-3 text-xs text-[#687771]">Mayor uso en el período: <b className="text-[#173c3a]">{paymentData[0].method}, {money(paymentData[0].value)}</b>.</p>}</Panel><DataBackup entries={entries} budgets={budgets} categories={categories} categoryAppearances={categoryAppearances} paymentMethods={paymentMethods} message={backupMessage} onMessage={onBackupMessage} onImportPreview={onImportPreview}/></div><Panel title="Presupuestos" subtitle={`Avance ajustado a ${periodLabel}`} action={<Button variant="link" onClick={onBudgets} className="p-0 text-[#2f6b65]">Editar presupuesto mensual</Button>}>{categoryData.map((item: any) => <div key={item.category} className="mb-4"><div className="flex justify-between gap-3 text-sm"><span>{item.category}</span><span>{money(item.value)} <small className="text-[#687771]">/ {money(item.budget)}</small></span></div><Progress value={Math.min(100, item.value / (item.budget || 1) * 100)} className="mt-2 h-2 bg-[#eee7d8] [&>div]:bg-[#2f6b65]"/></div>)}<div className="rounded-xl bg-[#e1eee8] p-3 text-sm"><b>Presupuesto mensual base</b><span className="float-right font-mono">{money(total)}</span><p className="mt-1 text-xs text-[#687771]">Las vistas semanal y anual usan una proporción de este presupuesto.</p></div></Panel></div>;
}

async function exportDashboardExcel(data: any) {
  const XLSX = await import("xlsx"); const workbook = XLSX.utils.book_new();
  const summary = XLSX.utils.json_to_sheet([{ Período: data.periodLabel, Vista: data.periodMode === "week" ? "Semana" : data.periodMode === "month" ? "Mes" : "Año", Ingresos: data.earned, Gastos: data.spent, Saldo: data.earned - data.spent, Presupuesto: data.budget, Proyección: data.projected, "Variación gasto anterior": data.spent - data.previousSpent }]);
  const categories = XLSX.utils.json_to_sheet(data.categoryData.map((item: any) => ({ Categoría: item.category, Gastado: item.value, Presupuesto: item.budget, Disponible: item.budget - item.value, "% utilizado": item.budget ? Math.round(item.value / item.budget * 100) : 0 })));
  const annual = XLSX.utils.json_to_sheet(data.annualData.map((item: any) => ({ Mes: item.month, Ingresos: item.income, Gastos: item.expense, Saldo: item.income - item.expense })));
  const movements = XLSX.utils.json_to_sheet(data.entries.map((item: Entry) => ({ Fecha: item.date, Tipo: item.kind === "expense" ? "Gasto" : "Ingreso", Monto: item.amount, Categoría: item.category, Subcategoría: item.subcategory, "Medio de pago": item.paymentSource, Nota: item.note })));
  summary["!cols"] = [{ wch: 28 }, { wch: 12 }, ...Array(6).fill({ wch: 18 })]; categories["!cols"] = [{ wch: 24 }, ...Array(4).fill({ wch: 16 })]; annual["!cols"] = [{ wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 16 }]; movements["!cols"] = [{ wch: 13 }, { wch: 12 }, { wch: 14 }, { wch: 22 }, { wch: 24 }, { wch: 22 }, { wch: 32 }];
  XLSX.utils.book_append_sheet(workbook, summary, "Resumen"); XLSX.utils.book_append_sheet(workbook, categories, "Categorías"); XLSX.utils.book_append_sheet(workbook, annual, "Evolución anual"); XLSX.utils.book_append_sheet(workbook, movements, "Movimientos");
  XLSX.writeFile(workbook, `dashboard-mis-cuentas-${data.periodMode}.xlsx`, { compression: true });
}

async function exportDashboardPdf(data: any) {
  const { jsPDF } = await import("jspdf"); const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" }); const width = doc.internal.pageSize.getWidth();
  doc.setFillColor(23, 63, 61); doc.rect(0, 0, width, 34, "F"); doc.setTextColor(255, 250, 240); doc.setFontSize(22); doc.text("Mis Cuentas", 16, 15); doc.setFontSize(11); doc.text(`Dashboard financiero · ${data.periodLabel}`, 16, 24);
  const cards = [["Ingresos", data.earned], ["Gastos", data.spent], ["Saldo", data.earned - data.spent], ["Presupuesto", data.budget]]; cards.forEach(([label, value], index) => { const x = 16 + index * 68; doc.setFillColor(245, 240, 229); doc.roundedRect(x, 43, 60, 25, 3, 3, "F"); doc.setTextColor(81, 101, 95); doc.setFontSize(9); doc.text(String(label), x + 5, 51); doc.setTextColor(23, 60, 58); doc.setFontSize(16); doc.text(money(Number(value)), x + 5, 62); });
  doc.setFontSize(14); doc.text("Gasto por categoría", 16, 82); const maxCategory = Math.max(1, ...data.categoryData.map((item: any) => item.value)); data.categoryData.slice(0, 8).forEach((item: any, index: number) => { const y = 92 + index * 10; doc.setFontSize(9); doc.setTextColor(23, 60, 58); doc.text(item.category, 16, y); doc.setFillColor(225, 238, 232); doc.rect(68, y - 4, 80, 5, "F"); doc.setFillColor(47, 107, 101); doc.rect(68, y - 4, 80 * item.value / maxCategory, 5, "F"); doc.text(money(item.value), 152, y); });
  doc.setFontSize(14); doc.text("Evolución anual", 182, 82); const maxMonth = Math.max(1, ...data.annualData.flatMap((item: any) => [item.income, item.expense])); data.annualData.forEach((item: any, index: number) => { const x = 183 + index * 8; const base = 165; const incomeH = 55 * item.income / maxMonth; const expenseH = 55 * item.expense / maxMonth; doc.setFillColor(95, 143, 115); doc.rect(x, base - incomeH, 3, incomeH, "F"); doc.setFillColor(185, 95, 77); doc.rect(x + 3.5, base - expenseH, 3, expenseH, "F"); doc.setFontSize(6); doc.setTextColor(81, 101, 95); doc.text(item.month.slice(0, 3), x, 171); });
  doc.setFontSize(8); doc.setTextColor(81, 101, 95); doc.text("Verde: ingresos · Rojo: gastos", 182, 181); doc.text(`Generado el ${new Intl.DateTimeFormat("es-PE", { dateStyle: "long" }).format(new Date())}. Datos guardados en este dispositivo.`, 16, 194);
  doc.save(`dashboard-mis-cuentas-${data.periodMode}.pdf`);
}

function ProgressView({ projected, budget, categoryData, entries, annualData, periodLabel, periodMode, earned, spent, previousEarned, previousSpent, onPlan }: any) {
  const difference = spent - previousSpent; const exportData = { projected, budget, categoryData, entries, annualData, periodLabel, periodMode, earned, spent, previousEarned, previousSpent };
  return <div className="grid min-h-[420px] content-start gap-5 lg:grid-cols-2"><section className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#d8cdae] bg-[#fffdf8] p-4 shadow-sm lg:col-span-2"><div><h2 className="font-serif text-xl">Dashboard de {periodLabel}</h2><p className="text-xs text-[#687771]">Descarga el período seleccionado con sus movimientos y el panorama anual.</p></div><div className="flex gap-2"><Button variant="outline" onClick={() => void exportDashboardExcel(exportData)}><FileSpreadsheet className="size-4"/>Excel</Button><Button className="bg-[#173c3a] text-white" onClick={() => void exportDashboardPdf(exportData)}><FileText className="size-4"/>PDF</Button></div></section><Panel title="Comparación con el período anterior" subtitle="Cálculo real con movimientos guardados"><p className={`font-mono text-2xl ${difference <= 0 ? "text-[#4e7e63]" : "text-[#b95f4d]"}`}>{difference === 0 ? "Sin variación" : `${money(Math.abs(difference))} ${difference < 0 ? "menos" : "más"}`}</p><p className="mt-2 text-sm text-[#687771]">Antes gastaste {money(previousSpent)} e ingresaste {money(previousEarned)}.</p></Panel><Panel title="Proyección del período" subtitle="Según el ritmo actual"><p className="font-serif text-3xl">{money(projected)}</p><p className="mt-2 text-sm text-[#687771]">Presupuesto de referencia: {money(budget)}.</p><Button onClick={onPlan} className="mt-4 bg-[#173c3a] text-white">Revisar mi plan</Button></Panel><Panel title="Panorama anual" subtitle="Ingresos y gastos por mes"><div className="h-64"><ResponsiveContainer><BarChart data={annualData}><XAxis dataKey="month" axisLine={false} tickLine={false}/><Tooltip formatter={(value: number, name: string) => [money(value), name === "income" ? "Ingresos" : "Gastos"]}/><Bar dataKey="income" fill="#5f8f73" radius={[5,5,0,0]}/><Bar dataKey="expense" fill="#b95f4d" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div><div className="flex gap-4 text-xs text-[#687771]"><span><i className="mr-1 inline-block size-2 rounded-full bg-[#5f8f73]"/>Ingresos</span><span><i className="mr-1 inline-block size-2 rounded-full bg-[#b95f4d]"/>Gastos</span></div></Panel><section className="rounded-2xl border border-[#d8cdae] bg-[#fffdf8] p-5 shadow-sm"><div><h2 className="font-serif text-xl">Presupuesto y gasto real</h2><p className="mt-1 text-xs leading-5 text-[#687771]">Avance de {periodLabel} por categoría</p></div><div className="mt-5 grid gap-3">{categoryData.map((item: any) => { const percent = item.budget ? Math.round(item.value / item.budget * 100) : 0; const available = item.budget - item.value; const over = available < 0; return <article key={item.category} className="rounded-xl border border-[#e5dcc8] bg-white p-4"><div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold">{item.category}</h3><p className="mt-1"><b className="font-mono text-xl">{money(item.value)}</b> <span className="text-sm text-[#687771]">gastados</span></p></div><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${over ? "bg-[#f7dfd9] text-[#9c4938]" : "bg-[#e1eee8] text-[#2f6b65]"}`}>{percent}% usado</span></div><Progress value={Math.min(100, percent)} className={`mt-3 h-2 bg-[#eee7d8] ${over || percent >= 90 ? "[&>div]:bg-[#b95f4d]" : "[&>div]:bg-[#2f6b65]"}`}/><div className="mt-3 grid grid-cols-2 gap-2 text-xs text-[#687771]"><span>Presupuesto<b className="mt-0.5 block font-mono text-sm text-[#173c3a]">{money(item.budget)}</b></span><span>{over ? "Exceso" : "Disponible"}<b className={`mt-0.5 block font-mono text-sm ${over ? "text-[#b95f4d]" : "text-[#173c3a]"}`}>{money(Math.abs(available))}</b></span></div></article>; })}</div></section></div>;
}

function QuickEntry({ onSubmit }: { onSubmit: (text: string) => boolean }) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const submit = () => { if (onSubmit(text)) { setText(""); setError(""); } else setError("Incluye un monto y una idea sencilla, por ejemplo: “Ayer gasté 35 en taxi con Yape”."); };
  return <Panel title="Registro rápido" subtitle="Escribe una frase sencilla; se completa el formulario para que la confirmes"><div className="flex gap-2"><div className="relative flex-1"><MessageSquareText className="absolute left-3 top-3 size-4 text-[#70807a]"/><Input value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") submit(); }} placeholder="Ej. Hoy gasté 18 en desayuno con Yape" className="bg-white pl-9 text-[#173c3a]"/></div><Button onClick={submit} disabled={!text.trim()} className="bg-[#2f6b65] text-white">Interpretar</Button></div>{error ? <p role="alert" className="mt-2 text-xs text-[#a34f3f]">{error}</p> : <p className="mt-2 text-xs text-[#687771]">Reconoce monto, hoy/ayer, gastos comunes y medios como efectivo, Yape o tarjetas. Funciona localmente, sin IA.</p>}</Panel>;
}

function CategoryDetailDialog({ category, entries, periodLabel, appearances, color, onClose, onViewMovements }: { category: string | null; entries: Entry[]; periodLabel: string; appearances: CategoryAppearances; color: string; onClose: () => void; onViewMovements: () => void }) {
  const total = entries.reduce((sum, item) => sum + item.amount, 0);
  const breakdown = Array.from(new Set(entries.map((item) => item.subcategory))).map((subcategory, index) => ({ subcategory, value: entries.filter((item) => item.subcategory === subcategory).reduce((sum, item) => sum + item.amount, 0), color: [color, ...CATEGORY_COLOR_CHOICES.filter((candidate) => candidate !== color)][index % CATEGORY_COLOR_CHOICES.length] }));
  return <Dialog open={Boolean(category)} onOpenChange={(open) => !open && onClose()}><DialogContent className="max-h-[90vh] overflow-y-auto border-[#d8cdae] bg-[#fffdf8] text-[#173c3a] sm:max-w-2xl"><DialogHeader><DialogTitle className="flex items-center gap-3 font-serif text-2xl">{category && <CategoryIcon category={category} appearances={appearances}/>} {category}</DialogTitle><DialogDescription className="text-[#687771]">{entries.length} {entries.length === 1 ? "movimiento" : "movimientos"} en {periodLabel} · {money(total)} en total</DialogDescription></DialogHeader>{entries.length > 0 && <div className="grid gap-4 sm:grid-cols-[190px_1fr]"><div><div className="relative h-44"><ResponsiveContainer><PieChart><Pie data={breakdown} dataKey="value" nameKey="subcategory" innerRadius={48} outerRadius={72} paddingAngle={3}>{breakdown.map((item) => <Cell key={item.subcategory} fill={item.color}/>)}</Pie><Tooltip formatter={(value: number) => money(value)}/></PieChart></ResponsiveContainer><div className="pointer-events-none absolute inset-0 grid place-content-center text-center"><span className="text-xs text-[#687771]">Total</span><b className="font-mono text-lg">{money(total)}</b></div></div><div className="space-y-1">{breakdown.map((item) => <div key={item.subcategory} className="flex items-center gap-2 text-xs"><i className="size-2 rounded-full" style={{ background: item.color }}/><span className="flex-1">{item.subcategory}</span><b>{money(item.value)}</b></div>)}</div></div><div className="space-y-2">{entries.slice().sort((a,b) => b.date.localeCompare(a.date)).map((item) => { const subColor = breakdown.find((part) => part.subcategory === item.subcategory)?.color ?? color; return <div key={item.id} className="flex items-center gap-3 rounded-xl border p-3" style={{ borderColor: `${subColor}55`, backgroundColor: `${subColor}12` }}><CategoryIcon category={item.category} appearances={{ ...appearances, [item.category]: { ...getCategoryAppearance(item.category, appearances), color: subColor } }} size="sm"/><span className="min-w-0 flex-1"><b className="block truncate text-sm">{item.note || item.subcategory}</b><small className="block truncate text-[#687771]">{dateLabel(item.date)} · {item.subcategory} · {item.paymentSource || "No especificado"}</small></span><b className="font-mono text-sm">{money(item.amount)}</b></div>; })}</div></div>}<div className="flex justify-end"><Button variant="outline" onClick={onViewMovements}>Ir a Movimientos</Button></div></DialogContent></Dialog>;
}

function DayDetailDialog({ date, entries, categories, appearances, onClose, onViewMovements }: { date: string | null; entries: Entry[]; categories: any[]; appearances: CategoryAppearances; onClose: () => void; onViewMovements: () => void }) {
  const total = entries.reduce((sum, item) => sum + item.amount, 0);
  const breakdown = categories.map((category) => ({ ...category, value: entries.filter((item) => item.category === category.category).reduce((sum, item) => sum + item.amount, 0) })).filter((item) => item.value > 0);
  return <Dialog open={Boolean(date)} onOpenChange={(open) => !open && onClose()}><DialogContent className="max-h-[90vh] overflow-y-auto border-[#d8cdae] bg-[#fffdf8] text-[#173c3a] sm:max-w-xl"><DialogHeader><DialogTitle className="font-serif text-2xl">Gastos del {date ? dateLabel(date) : "día"}</DialogTitle><DialogDescription className="text-[#687771]">{entries.length ? `${entries.length} ${entries.length === 1 ? "movimiento" : "movimientos"} · ${money(total)} en total` : "No registraste gastos este día."}</DialogDescription></DialogHeader>{entries.length > 0 && <div className="grid gap-4 sm:grid-cols-[180px_1fr]"><div className="relative h-44"><ResponsiveContainer><PieChart><Pie data={breakdown} dataKey="value" innerRadius={48} outerRadius={72} paddingAngle={3}>{breakdown.map((item) => <Cell key={item.category} fill={item.color}/>)}</Pie><Tooltip formatter={(value: number) => money(value)}/></PieChart></ResponsiveContainer><div className="pointer-events-none absolute inset-0 grid place-content-center text-center"><span className="text-xs text-[#687771]">Total</span><b className="font-mono text-lg">{money(total)}</b></div></div><div className="space-y-2">{entries.map((item) => { const itemColor = categories.find((category) => category.category === item.category)?.color ?? "#2f6b65"; return <div key={item.id} className="flex items-center gap-3 rounded-xl border p-3" style={{ borderColor: `${itemColor}55`, backgroundColor: `${itemColor}12` }}><CategoryIcon category={item.category} appearances={appearances} size="sm"/><span className="min-w-0 flex-1"><b className="block truncate text-sm">{item.note || item.subcategory}</b><small className="block truncate text-[#687771]">{item.category} · {item.subcategory} · {item.paymentSource || "No especificado"}</small></span><b className="font-mono text-sm">{money(item.amount)}</b></div>; })}</div></div>}<div className="flex justify-end"><Button variant="outline" onClick={onViewMovements}>Ir a Movimientos</Button></div></DialogContent></Dialog>;
}

function DataBackup({ entries, budgets, categories, categoryAppearances, paymentMethods, message, onMessage, onImportPreview }: { entries: Entry[]; budgets: Record<string, number>; categories: Categories; categoryAppearances: CategoryAppearances; paymentMethods: string[]; message: string; onMessage: (message: string) => void; onImportPreview: (preview: ImportPreview) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const exportExcel = async () => {
    try {
      const XLSX = await import("xlsx");
      const workbook = XLSX.utils.book_new();
      const movements = entries.slice().sort((a, b) => a.date.localeCompare(b.date)).map((item) => ({
        ID: item.id,
        Tipo: item.kind === "expense" ? "Gasto" : "Ingreso",
        Monto: item.amount,
        Fecha: item.date,
        "Categoría": item.category,
        "Subcategoría": item.subcategory,
        "Medio de pago": item.paymentSource,
        Nota: item.note,
        Recurrente: item.recurring ? "Sí" : "No",
      }));
      const movementSheet = XLSX.utils.json_to_sheet(movements);
      movementSheet["!cols"] = [{ wch: 38 }, { wch: 12 }, { wch: 12 }, { wch: 13 }, { wch: 22 }, { wch: 24 }, { wch: 22 }, { wch: 32 }, { wch: 12 }];
      const budgetSheet = XLSX.utils.json_to_sheet(Object.entries(budgets).map(([category, amount]) => ({ "Categoría": category, Presupuesto: amount })));
      budgetSheet["!cols"] = [{ wch: 24 }, { wch: 16 }];
      const categorySheet = XLSX.utils.json_to_sheet(Object.entries(categories).flatMap(([category, subs]) => { const appearance = getCategoryAppearance(category, categoryAppearances); const base = { "Categoría": category, Icono: appearance.icon, Color: appearance.color }; return subs.length ? subs.map((subcategory) => ({ ...base, "Subcategoría": subcategory })) : [{ ...base, "Subcategoría": "" }]; }));
      categorySheet["!cols"] = [{ wch: 24 }, { wch: 28 }, { wch: 18 }, { wch: 14 }];
      const paymentSheet = XLSX.utils.json_to_sheet(paymentMethods.map((method) => ({ "Medio de pago": method })));
      paymentSheet["!cols"] = [{ wch: 28 }];
      XLSX.utils.book_append_sheet(workbook, movementSheet, "Movimientos");
      XLSX.utils.book_append_sheet(workbook, budgetSheet, "Presupuestos");
      XLSX.utils.book_append_sheet(workbook, categorySheet, "Categorías");
      XLSX.utils.book_append_sheet(workbook, paymentSheet, "Medios de pago");
      XLSX.writeFile(workbook, "mis-cuentas-respaldo.xlsx", { compression: true });
      onMessage("Excel exportado con todos tus datos, incluidos los medios de pago.");
    } catch {
      onMessage("No se pudo crear el archivo Excel. Intenta nuevamente.");
    }
  };
  const importExcel = async (file: File) => {
    try {
      const XLSX = await import("xlsx");
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: true });
      const movementSheet = workbook.Sheets["Movimientos"];
      if (!movementSheet) throw new Error("missing movements");
      const movementRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(movementSheet, { defval: "", raw: true });
      const parsedEntries = movementRows.map((row) => {
        const type = String(row.Tipo ?? "").trim().toLowerCase();
        const rawDate = row.Fecha;
        let date = "";
        if (rawDate instanceof Date) date = rawDate.toISOString().slice(0, 10);
        else if (typeof rawDate === "number") { const parsed = XLSX.SSF.parse_date_code(rawDate); if (parsed) date = `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`; }
        else date = String(rawDate ?? "").slice(0, 10);
        const amount = Number(row.Monto);
        const category = String(row["Categoría"] ?? "").trim();
        if (!Number.isFinite(amount) || amount <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !category || !["gasto", "ingreso", "expense", "income"].includes(type)) return null;
        return { id: String(row.ID || crypto.randomUUID()), kind: (["gasto", "expense"].includes(type) ? "expense" : "income") as Kind, amount, date, category, subcategory: String(row["Subcategoría"] ?? "General").trim() || "General", paymentSource: String(row["Medio de pago"] ?? "No especificado").trim() || "No especificado", note: String(row.Nota ?? "").trim(), recurring: ["sí", "si", "true", "1", "yes"].includes(String(row.Recurrente ?? "").trim().toLowerCase()) };
      }).filter((item): item is Entry => Boolean(item));
      if (!parsedEntries.length) throw new Error("no valid movements");
      const budgetRows = workbook.Sheets["Presupuestos"] ? XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets["Presupuestos"], { defval: "", raw: true }) : [];
      const parsedBudgets = budgetRows.reduce<Record<string, number>>((result, row) => { const category = String(row["Categoría"] ?? "").trim(); const amount = Number(row.Presupuesto); if (category && Number.isFinite(amount) && amount >= 0) result[category] = amount; return result; }, {});
      const categoryRows = workbook.Sheets["Categorías"] ? XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets["Categorías"], { defval: "", raw: true }) : [];
      const parsedCategories = categoryRows.reduce<Categories>((result, row) => { const category = String(row["Categoría"] ?? "").trim(); const subcategory = String(row["Subcategoría"] ?? "").trim(); if (category) { result[category] ??= []; if (subcategory && !result[category].includes(subcategory)) result[category].push(subcategory); } return result; }, {});
      const parsedAppearances = categoryRows.reduce<CategoryAppearances>((result, row) => { const category = String(row["Categoría"] ?? "").trim(); const icon = String(row.Icono ?? "") as CategoryIconKey; const color = String(row.Color ?? "").trim(); if (category && ICON_CHOICES.includes(icon) && /^#[0-9a-f]{6}$/i.test(color)) result[category] = { icon, color }; return result; }, {});
      const nextCategories = Object.keys(parsedCategories).length ? parsedCategories : categories;
      const paymentRows = workbook.Sheets["Medios de pago"] ? XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets["Medios de pago"], { defval: "", raw: true }) : [];
      const parsedMethods = paymentRows.map((row) => String(row["Medio de pago"] ?? "").trim()).filter(Boolean);
      onImportPreview({ fileName: file.name, entries: parsedEntries, budgets: Object.keys(parsedBudgets).length ? parsedBudgets : budgets, categories: nextCategories, categoryAppearances: withDefaultAppearances(nextCategories, Object.keys(parsedAppearances).length ? parsedAppearances : categoryAppearances), paymentMethods: parsedMethods.length ? parsedMethods : paymentMethods });
      onMessage("");
    } catch {
      onMessage("No se pudo importar. Usa un Excel exportado desde Mis Cuentas y conserva los nombres de las columnas.");
    } finally {
      if (inputRef.current) inputRef.current.value = "";
    }
  };
  return <Panel title="Respaldo en Excel" subtitle="Guarda una copia completa o recupera tus datos en este dispositivo"><div className="grid gap-2 sm:grid-cols-2"><Button onClick={exportExcel} className="bg-[#173c3a] text-white"><Download/>Exportar Excel</Button><Button variant="outline" onClick={() => inputRef.current?.click()}><Upload/>Importar Excel</Button><input ref={inputRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) void importExcel(file); }}/></div>{message && <p role="status" className="mt-3 rounded-lg bg-[#eee7d8] px-3 py-2 text-xs text-[#51655f]">{message}</p>}<p className="mt-3 flex items-start gap-2 text-xs leading-5 text-[#687771]"><FileSpreadsheet className="mt-0.5 size-4 shrink-0"/>El archivo incluye movimientos, presupuestos, categorías, subcategorías y medios de pago. Al importar, podrás confirmar antes de reemplazar tus datos actuales.</p></Panel>;
}

function LoansView({ loans, onSave, onDelete }: { loans: Loan[]; onSave: (loan: Loan) => void; onDelete: (id: string) => void }) {
  const emptyLoan = (): Loan => ({ id: "", name: "", principal: 10000, tcea: 25, months: 12, startDate: localISODate(), firstPaymentDate: monthlyDate(localISODate(), 1), paidMonths: 0 });
  const [form, setForm] = useState<Loan>(emptyLoan());
  const [selectedId, setSelectedId] = useState(loans[0]?.id ?? "");
  const [formOpen, setFormOpen] = useState(false);
  const [extra, setExtra] = useState(0);
  const [after, setAfter] = useState(0);
  const [strategy, setStrategy] = useState<"term" | "payment">("term");
  const [showScenario, setShowScenario] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => { if (!loans.some((loan) => loan.id === selectedId)) setSelectedId(loans[0]?.id ?? ""); }, [loans, selectedId]);
  const selected = loans.find((loan) => loan.id === selectedId) ?? null;
  const original = selected ? loanSchedule(selected) : [];
  const paid = Math.min(selected?.paidMonths ?? 0, original.length);
  useEffect(() => { setExtra(0); setAfter(selected?.paidMonths ?? 0); setShowScenario(false); }, [selectedId]);
  const validForm = Number.isFinite(form.principal) && form.principal > 0 && Number.isFinite(form.tcea) && form.tcea >= 0 && Number.isInteger(form.months) && form.months >= 1 && form.months <= 360 && Boolean(form.startDate && form.firstPaymentDate && form.firstPaymentDate > form.startDate);
  const preview = validForm ? loanSchedule(form) : [];
  const balance = after === 0 ? selected?.principal ?? 0 : original[after - 1]?.balance ?? 0;
  const validExtra = extra > 0 && extra <= balance && after >= paid && after < original.length;
  const scenario = selected && validExtra ? loanSchedule(selected, extra, after, strategy) : original;
  const rows = showScenario && validExtra ? scenario : original;
  const total = original.reduce((sum, row) => sum + row.payment, 0);
  const saving = Math.max(0, original.reduce((sum, row) => sum + row.interest, 0) - scenario.reduce((sum, row) => sum + row.interest, 0));
  const fullDate = (date?: string) => date ? new Intl.DateTimeFormat("es-PE", { dateStyle: "medium" }).format(parseISODate(date)) : "—";
  const submit = () => {
    if (!validForm || !form.name.trim() || !Number.isInteger(form.paidMonths ?? 0) || (form.paidMonths ?? 0) < 0 || (form.paidMonths ?? 0) > form.months) { setError("Revisa el monto, plazo y fechas. La primera cuota debe ser posterior al desembolso y las cuotas pagadas no pueden superar el plazo."); return; }
    const id = form.id || crypto.randomUUID(); onSave({ ...form, id, name: form.name.trim() }); setSelectedId(id); setFormOpen(false); setError("");
  };
  const summaryItem = (label: string, value: string) => <div className="min-w-0 rounded-xl bg-[#f5f0e5] p-4"><p className="text-sm text-[#687771]">{label}</p><b className="mt-1 block text-lg">{value}</b></div>;
  return <div className="min-w-0 space-y-6">
    <div className="flex flex-wrap items-center justify-between gap-4"><div><h2 className="font-serif text-2xl">Mis préstamos</h2><p className="mt-1 text-sm text-[#687771]">Fechas, saldo estimado y escenarios de pago anticipado.</p></div><Button onClick={() => { setForm(emptyLoan()); setError(""); setFormOpen(true); }} className="bg-[#173c3a] text-white"><Plus className="size-4"/>Agregar préstamo</Button></div>
    {loans.length > 0 && <div className="grid gap-3 sm:grid-cols-2">{loans.map((loan) => { const schedule = loanSchedule(loan); const count = Math.min(loan.paidMonths ?? 0, schedule.length); return <button key={loan.id} onClick={() => setSelectedId(loan.id)} className={`min-w-0 rounded-2xl border p-4 text-left ${selectedId === loan.id ? "border-[#2f6b65] bg-[#e1eee8] ring-1 ring-[#2f6b65]" : "border-[#d8cdae] bg-[#fffdf8]"}`}><span className="flex items-center gap-3"><Landmark className="size-5 shrink-0"/><b className="truncate">{loan.name}</b></span><span className="mt-3 block text-sm">{count} de {loan.months} cuotas pagadas · {money(loan.principal)}</span><span className="mt-1 block text-sm text-[#687771]">Termina: {fullDate(schedule.at(-1)?.date)}</span></button>; })}</div>}
    {selected ? <><Panel title={selected.name} subtitle="Datos del préstamo y avance registrado" action={<Button variant="outline" onClick={() => { setForm({ ...selected, firstPaymentDate: selected.firstPaymentDate || monthlyDate(selected.startDate, 1), paidMonths: paid }); setError(""); setFormOpen(true); }}><Pencil className="size-4"/>Editar</Button>}>
      <div className="grid gap-3 sm:grid-cols-3">{summaryItem("Monto original", money(selected.principal))}{summaryItem("TCEA anual", `${selected.tcea}%`)}{summaryItem("Plazo", `${selected.months} meses`)}{summaryItem("Desembolso", fullDate(selected.startDate))}{summaryItem("Primera cuota", fullDate(original[0]?.date))}{summaryItem("Última cuota", fullDate(original.at(-1)?.date))}</div>
      <div className="mt-5 grid gap-4 sm:grid-cols-3">{summaryItem("Saldo estimado", money(paid === 0 ? selected.principal : original[paid - 1]?.balance ?? 0))}{summaryItem("Próximo pago pendiente", fullDate(original[paid]?.date))}{summaryItem("Cuota aproximada", money(original[paid]?.payment ?? 0))}</div>
      <div className="mt-5 flex flex-wrap items-center gap-3"><Label>Cuotas que ya pagaste</Label><Input aria-label="Cuotas pagadas" className="w-24 bg-white" type="number" min="0" max={selected.months} value={paid} onChange={(event) => { const count = Number(event.target.value); if (Number.isInteger(count) && count >= 0 && count <= selected.months) { onSave({ ...selected, paidMonths: count }); setAfter(count); } }}/><span className="text-sm text-[#687771]">{paid === selected.months ? "Préstamo completado" : `${selected.months - paid} cuotas pendientes`}</span></div>
      <Progress value={paid / selected.months * 100} className="mt-3 h-2 bg-[#eee7d8] [&>div]:bg-[#2f6b65]"/>
    </Panel>
    <Panel title="¿Qué pasa si amortizo?" subtitle="Compara un abono adicional a capital después de pagar una cuota">
      <div className="grid items-end gap-4 sm:grid-cols-2"><Field label="Abono adicional (S/)"><Input type="number" min="0" max={balance} value={extra || ""} placeholder="Ej. 2000" onChange={(event) => setExtra(Number(event.target.value))} className="bg-white"/></Field><Field label="Momento del abono"><select value={after} onChange={(event) => setAfter(Number(event.target.value))} className="h-10 w-full rounded-md border border-[#d8cdae] bg-white px-3 text-sm">{Array.from({ length: Math.max(0, original.length - paid) }, (_, index) => paid + index).map((count) => <option key={count} value={count}>{count === 0 ? "En la fecha de desembolso" : `Después de cuota ${count} · ${fullDate(original[count - 1]?.date)}`}</option>)}</select></Field></div>
      <p className="mt-2 text-sm text-[#687771]">Saldo en ese momento: {money(balance)}. El abono se aplica en esa fecha.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">{(["term", "payment"] as const).map((mode) => <button key={mode} onClick={() => setStrategy(mode)} className={`rounded-xl border p-4 text-left ${strategy === mode ? "border-[#2f6b65] bg-[#e1eee8]" : "border-[#d8cdae] bg-white"}`}><b>{mode === "term" ? "Reducir plazo" : "Reducir cuota"}</b><span className="mt-1 block text-sm text-[#687771]">{mode === "term" ? "Mantienes la cuota y terminas antes." : "Mantienes la fecha final y pagas menos al mes."}</span></button>)}</div>
      {extra > balance && <p role="alert" className="mt-3 text-sm text-[#b95f4d]">El abono no puede superar el saldo de {money(balance)}.</p>}
      {validExtra && <div className="mt-5 space-y-4"><div className="grid gap-3 sm:grid-cols-3">{summaryItem("Ahorro estimado en costos", money(saving))}{summaryItem(strategy === "term" ? "Cuotas que reduces" : "Nueva cuota aprox.", strategy === "term" ? String(original.length - scenario.length) : money(scenario[after]?.payment ?? 0))}{summaryItem("Nueva fecha final", fullDate(scenario.at(-1)?.date ?? (after === 0 ? selected.startDate : original[after - 1]?.date)))}</div><Button variant="outline" onClick={() => setShowScenario(!showScenario)}>{showScenario ? "Ver cronograma original" : "Ver cronograma con amortización"}</Button><p className="text-sm text-[#687771]">Esta comparación no cambia tu préstamo guardado ni tus movimientos.</p></div>}
    </Panel>
    <Panel title={showScenario && validExtra ? "Cronograma con amortización" : "Cronograma original"} subtitle={`Total original estimado: ${money(total)} · Capital: ${money(selected.principal)} · Costo financiero: ${money(total - selected.principal)}`}>
      <div className="max-h-[480px] w-full min-w-0 overflow-auto rounded-xl border border-[#e5dcc8]"><table className="w-full min-w-[700px] text-left text-sm"><thead className="sticky top-0 bg-[#173c3a] text-white"><tr>{["Cuota", "Fecha", "Pago", "Capital", "Costo financiero", "Abono extra", "Saldo"].map((label) => <th key={label} className="whitespace-nowrap p-3">{label}</th>)}</tr></thead><tbody>{rows.map((row) => <tr key={row.number} className={`border-b border-[#e5dcc8] ${row.number <= paid ? "bg-[#e1eee8]" : "odd:bg-[#f8f5ed]"}`}><td className="p-3">{row.number}{row.number <= paid ? " ✓" : ""}</td><td className="whitespace-nowrap p-3">{fullDate(row.date)}</td>{[row.payment, row.principal, row.interest, row.extra, row.balance].map((value, index) => <td key={index} className="whitespace-nowrap p-3 font-mono">{money(value)}</td>)}</tr>)}</tbody></table></div>
      <p className="mt-4 text-sm leading-6 text-[#687771]">Estimación con TCEA y días reales sobre un año de 365 días. El costo financiero agrupa los costos implícitos en la TCEA; no desglosa el interés y seguros del banco. El saldo depende de las cuotas que marques como pagadas. <a href="https://www.sbs.gob.pe/usuarios/aprende-con-la-sbs/credito-hipotecario-para-vivienda" target="_blank" rel="noreferrer" className="underline">Sobre pagos anticipados · SBS</a></p><Button variant="ghost" className="mt-3 text-[#b95f4d]" onClick={() => setDeleteOpen(true)}><Trash2 className="size-4"/>Eliminar préstamo</Button>
    </Panel></> : <Panel title="Agrega tu primer préstamo"><p className="text-[#687771]">Registra los datos de tu crédito para ver su fecha final, las cuotas pendientes y comparar amortizaciones.</p></Panel>}
    <Sheet open={formOpen} onOpenChange={setFormOpen}><SheetContent side="bottom" className="max-h-[92vh] overflow-y-auto rounded-t-3xl bg-[#fffdf8] text-[#173c3a] sm:left-1/2 sm:right-auto sm:w-full sm:max-w-2xl sm:-translate-x-1/2"><SheetHeader><SheetTitle>{form.id ? "Editar préstamo" : "Agregar préstamo"}</SheetTitle></SheetHeader><div className="space-y-5 px-4"><Field label="Nombre"><Input value={form.name} placeholder="Ej. Mi préstamo BCP" onChange={(event) => setForm({ ...form, name: event.target.value })}/></Field><div className="grid gap-4 sm:grid-cols-2"><Field label="Monto original (S/)"><Input type="number" value={form.principal} onChange={(event) => setForm({ ...form, principal: Number(event.target.value) })}/></Field><Field label="TCEA anual (%)"><Input type="number" min="0" step="0.01" value={form.tcea} onChange={(event) => setForm({ ...form, tcea: Number(event.target.value) })}/></Field><Field label="Número de cuotas mensuales"><Input type="number" min="1" max="360" value={form.months} onChange={(event) => setForm({ ...form, months: Number(event.target.value) })}/></Field><Field label="Cuotas ya pagadas"><Input type="number" min="0" max={form.months} value={form.paidMonths ?? 0} onChange={(event) => setForm({ ...form, paidMonths: Number(event.target.value) })}/></Field><Field label="Fecha de desembolso"><Input type="date" value={form.startDate} onChange={(event) => setForm({ ...form, startDate: event.target.value })}/></Field><Field label="Fecha de primera cuota"><Input type="date" value={form.firstPaymentDate || ""} onChange={(event) => setForm({ ...form, firstPaymentDate: event.target.value })}/></Field></div><div className="min-h-24 rounded-xl bg-[#e1eee8] p-4"><p className="text-sm">Cuota mensual estimada</p><b className="text-2xl">{preview[0] ? money(preview[0].payment) : "—"}</b><p className="text-sm">Finaliza: {fullDate(preview.at(-1)?.date)}</p></div>{error && <p role="alert" className="text-sm text-[#b95f4d]">{error}</p>}</div><SheetFooter><Button onClick={submit} className="bg-[#173c3a] text-white">Guardar préstamo</Button></SheetFooter></SheetContent></Sheet>
    <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Eliminar este préstamo?</AlertDialogTitle><AlertDialogDescription>Se eliminará el préstamo guardado en este dispositivo.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => { if (selected) onDelete(selected.id); setDeleteOpen(false); }} className="bg-[#b95f4d]">Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
  </div>;
}

function BottomNav({ tab, setTab }: { tab: Tab; setTab: (tab: Tab) => void }) {
  const [moreOpen, setMoreOpen] = useState(false);
  const items: [Tab,string,typeof Home][] = [["home","Inicio",Home],["movements","Movimientos",ReceiptText],["plan","Plan",WalletCards],["progress","Progreso",BarChart3]];
  return <><nav className="z-40 grid w-full shrink-0 grid-cols-5 border-t border-[#d8cdae] bg-[#fffdf8]/95 px-2 pt-2 pb-[calc(.5rem+env(safe-area-inset-bottom))] shadow-[0_-8px_24px_rgba(23,60,58,.10)] backdrop-blur">{items.map(([id,label,Icon]) => <button key={id} onClick={() => setTab(id)} className={`grid min-h-12 min-w-0 place-items-center gap-1 rounded-xl px-1 text-xs ${tab === id ? "bg-[#e1eee8] text-[#2f6b65]" : "text-[#687771]"}`}><Icon className="size-5"/><span className="truncate">{label}</span></button>)}<button onClick={() => setMoreOpen(true)} className={`grid min-h-12 min-w-0 place-items-center gap-1 rounded-xl px-1 text-xs ${tab === "loans" ? "bg-[#e1eee8] text-[#2f6b65]" : "text-[#687771]"}`}><MoreHorizontal className="size-5"/><span>Más</span></button></nav><Dialog open={moreOpen} onOpenChange={setMoreOpen}><DialogContent className="border-[#d8cdae] bg-[#fffdf8] text-[#173c3a] sm:max-w-sm"><DialogHeader><DialogTitle className="font-serif text-2xl">Más herramientas</DialogTitle><DialogDescription>Funciones financieras adicionales.</DialogDescription></DialogHeader><button onClick={() => { setTab("loans"); setMoreOpen(false); }} className="flex items-center gap-3 rounded-2xl border border-[#d8cdae] bg-white p-4 text-left hover:bg-[#e1eee8]"><span className="rounded-xl bg-[#e1eee8] p-3 text-[#2f6b65]"><Landmark className="size-5"/></span><span><b className="block">Simulador de préstamos</b><small className="text-[#687771]">Cuotas, intereses y amortización</small></span></button></DialogContent></Dialog></>;
}

function Panel({ title, subtitle, action, children }: { title: string; subtitle?: string; action?: React.ReactNode; children: React.ReactNode }) { return <section className="rounded-2xl border border-[#d8cdae] bg-[#fffdf8] p-5 shadow-sm"><div className="flex items-start justify-between gap-3"><div><h2 className="font-serif text-xl">{title}</h2>{subtitle && <p className="mt-1 text-xs leading-5 text-[#687771]">{subtitle}</p>}</div>{action}</div><div className="mt-4">{children}</div></section>; }
function Metric({ label, value, detail }: { label: string; value: string; detail: string }) { return <div className="rounded-2xl border border-[#d8cdae] bg-[#fffdf8] p-4 shadow-sm"><p className="text-xs text-[#687771]">{label}</p><p className="mt-1 font-mono text-lg">{value}</p><p className="mt-1 text-xs text-[#687771]">{detail}</p></div>; }

function EntrySheet({ draft, categories, paymentMethods, onClose, onSave }: { draft: Entry | null; categories: Categories; paymentMethods: string[]; onClose: () => void; onSave: (entry: Entry) => void }) {
  const [form, setForm] = useState<Entry | null>(draft);
  useEffect(() => setForm(draft), [draft]);
  if (!form) return null;
  const income = form.kind === "income";
  const categoryOptions = income ? INCOME_SOURCES : Object.keys(categories);
  const subOptions = income ? ["Recurrente mensual", "Extraordinario", "Variable"] : categories[form.category] ?? ["General"];
  const update = <K extends keyof Entry>(key: K, value: Entry[K]) => setForm({ ...form, [key]: value });
  return <Sheet open={Boolean(draft)} onOpenChange={(open) => !open && onClose()}><SheetContent side="bottom" className="max-h-[92vh] overflow-y-auto rounded-t-[28px] bg-[#fffdf8] text-[#173c3a] sm:left-1/2 sm:right-auto sm:w-full sm:max-w-xl sm:-translate-x-1/2 sm:rounded-3xl"><SheetHeader><SheetTitle className="font-serif text-2xl text-[#173c3a]">{form.id ? "Editar movimiento" : income ? "Registrar ingreso" : "Registrar gasto"}</SheetTitle></SheetHeader><div className="space-y-4 px-4"><div className="grid grid-cols-2 rounded-xl bg-[#eee7d8] p-1"><Button variant={!income ? "default" : "ghost"} onClick={() => setForm({ ...form, kind:"expense", category:Object.keys(categories)[0], subcategory:Object.values(categories)[0]?.[0] ?? "General" })} className={!income ? "bg-[#173c3a] text-white" : "text-[#173c3a]"}>Gasto</Button><Button variant={income ? "default" : "ghost"} onClick={() => setForm({ ...form, kind:"income", category:"Trabajo principal", subcategory:"Extraordinario" })} className={income ? "bg-[#173c3a] text-white" : "text-[#173c3a]"}>Ingreso</Button></div><Field label="Monto"><Input type="number" value={form.amount || ""} onChange={(event) => update("amount", Number(event.target.value))} className="bg-white text-[#173c3a]"/></Field><div className="grid grid-cols-2 gap-3"><Field label="Fecha"><Input type="date" value={form.date} onChange={(event) => update("date", event.target.value)} className="bg-white text-[#173c3a]"/></Field><Field label={income ? "Origen" : "Categoría"}><select value={form.category} onChange={(event) => { const category = event.target.value; setForm({ ...form, category, subcategory: income ? "Extraordinario" : categories[category]?.[0] ?? "General" }); }} className="h-10 w-full rounded-md border border-[#d8cdae] bg-white px-3 text-[#173c3a]">{categoryOptions.map((option) => <option key={option}>{option}</option>)}</select></Field></div><div className="grid grid-cols-2 gap-3"><Field label={income ? "Frecuencia" : "Subcategoría"}><select value={form.subcategory} onChange={(event) => update("subcategory", event.target.value)} className="h-10 w-full rounded-md border border-[#d8cdae] bg-white px-3 text-[#173c3a]">{subOptions.map((option) => <option key={option}>{option}</option>)}</select></Field><Field label="Medio de pago"><select value={form.paymentSource || "No especificado"} onChange={(event) => update("paymentSource", event.target.value)} className="h-10 w-full rounded-md border border-[#d8cdae] bg-white px-3 text-[#173c3a]"><option>No especificado</option>{paymentMethods.map((option) => <option key={option}>{option}</option>)}</select></Field></div><Field label="Nota"><Input value={form.note} onChange={(event) => update("note", event.target.value)} placeholder="Opcional" className="bg-white text-[#173c3a]"/></Field>{income && <label className="block rounded-xl bg-[#e1eee8] p-3 text-sm"><input type="checkbox" className="mr-2" checked={form.recurring} onChange={(event) => update("recurring", event.target.checked)}/>Repetir cada mes</label>}</div><SheetFooter><Button disabled={!form.amount || !form.date} onClick={() => onSave(form)} className="bg-[#2f6b65] text-white">Guardar movimiento</Button></SheetFooter></SheetContent></Sheet>;
}

const BUDGET_GUIDES: Record<string, [number, number]> = {
  Vivienda: [20, 30], Alimentación: [8, 15], Transporte: [5, 15], Salud: [5, 10], Educación: [5, 10], Entretenimiento: [5, 10], "Ahorro e inversión": [10, 20], Otros: [0, 10],
};

function BudgetSheet({ open, budgets, categories, monthlyIncome, onClose, onSave }: { open: boolean; budgets: Record<string, number>; categories: Categories; monthlyIncome: number; onClose: () => void; onSave: (value: Record<string, number>) => void }) {
  const [draft,setDraft] = useState(budgets);
  useEffect(() => setDraft(budgets), [budgets,open]);
  const total = Object.values(draft).reduce((sum, value) => sum + Number(value || 0), 0);
  return <Sheet open={open} onOpenChange={(value) => !value && onClose()}><SheetContent side="bottom" className="max-h-[94vh] overflow-y-auto rounded-t-[28px] bg-[#fffdf8] text-[#173c3a] sm:left-1/2 sm:right-auto sm:w-full sm:max-w-2xl sm:-translate-x-1/2 sm:rounded-3xl"><SheetHeader><SheetTitle className="font-serif text-2xl text-[#173c3a]">Presupuesto mensual con guía</SheetTitle></SheetHeader><div className="space-y-4 px-4">
    <section className="rounded-2xl bg-[#e1eee8] p-4"><div className="flex items-center justify-between gap-3"><div><b>Tu referencia: {money(monthlyIncome)} de ingresos</b><p className="mt-1 text-xs leading-5 text-[#51655f]">Como punto de partida: hasta 50% para necesidades, cerca de 20% para ahorro e inversión y hasta 30% para deseos. Adáptalo a tu realidad.</p></div><Sparkles className="size-6 shrink-0 text-[#2f6b65]"/></div><div className="mt-3 h-2 overflow-hidden rounded-full bg-white"><div className="h-full rounded-full bg-[#d1a039]" style={{ width: `${monthlyIncome ? Math.min(100, total / monthlyIncome * 100) : 0}%` }}/></div><p className="mt-2 text-xs"><b>{money(total)}</b> planificados · {monthlyIncome ? `${Math.round(total / monthlyIncome * 100)}% de tus ingresos` : "registra ingresos para calcular porcentajes"}</p></section>
    <div className="space-y-3">{Object.keys(categories).map((category) => {
      const range = BUDGET_GUIDES[category]; const amount = Number(draft[category] ?? 0); const percentage = monthlyIncome ? amount / monthlyIncome * 100 : 0;
      const status = !range || !monthlyIncome ? "Referencia no disponible" : percentage < range[0] ? "Debajo de la guía" : percentage > range[1] ? "Por encima de la guía" : "Dentro de la guía";
      return <div key={category} className="rounded-xl border border-[#d8cdae] bg-white p-3"><div className="flex items-start justify-between gap-3"><div><Label>{category}</Label>{range && <p className="mt-1 text-xs text-[#687771]">Guía flexible: {range[0]}–{range[1]}% · {monthlyIncome ? `${money(monthlyIncome * range[0] / 100)}–${money(monthlyIncome * range[1] / 100)}` : "según tus ingresos"}</p>}</div><Input type="number" min="0" className="w-32 bg-[#fffdf8] font-mono text-[#173c3a]" value={amount} onChange={(event) => setDraft({ ...draft, [category]: Math.max(0, Number(event.target.value)) })}/></div><p className={`mt-2 text-xs ${status === "Dentro de la guía" ? "text-[#2f6b65]" : "text-[#8a6730]"}`}>{monthlyIncome ? `${percentage.toFixed(1)}% de tus ingresos · ` : ""}{status}</p></div>;
    })}</div>
    <aside className="rounded-xl border border-[#d8cdae] bg-[#f5f0e5] p-3 text-xs leading-5 text-[#51655f]"><b>Esto es orientación, no una regla.</b> Los porcentajes combinan el marco 50/30/20, la referencia de vivienda del 30% y rangos de gasto consciente. No reemplazan asesoría financiera. <span className="block pt-1"><a className="underline" href="https://www.consumerfinance.gov/consumer-tools/educator-tools/youth-financial-education/teach/activities/analyzing-budgets/" target="_blank" rel="noreferrer">CFPB</a> · <a className="underline" href="https://www.huduser.gov/portal/publications/affhsg/trends_hsg_cost.html" target="_blank" rel="noreferrer">HUD</a> · <a className="underline" href="https://www.iwillteachyoutoberich.com/how-to-budget/" target="_blank" rel="noreferrer">Conscious Spending Plan</a></span></aside>
  </div><SheetFooter><Button onClick={() => onSave(draft)} className="bg-[#2f6b65] text-white">Guardar presupuestos</Button></SheetFooter></SheetContent></Sheet>;
}

function CategorySheet({ open, categories, appearances, onClose, onSave }: { open:boolean; categories:Categories; appearances:CategoryAppearances; onClose:()=>void; onSave:(value:Categories, appearances:CategoryAppearances)=>void }) {
  const [draft,setDraft] = useState<Categories>(categories); const [appearanceDraft,setAppearanceDraft] = useState<CategoryAppearances>(appearances); const [newCategory,setNewCategory] = useState(""); const [newSubs,setNewSubs] = useState<Record<string,string>>({}); const [activePicker,setActivePicker] = useState<string | null>(null); const [newAppearance,setNewAppearance] = useState<CategoryAppearance>({ icon:"shopping", color:CATEGORY_COLOR_CHOICES[0] });
  useEffect(() => { setDraft(categories); setAppearanceDraft(withDefaultAppearances(categories, appearances)); setActivePicker(null); }, [categories,appearances,open]);
  const addCategory = () => { const name = newCategory.trim(); if (name && !draft[name]) { setDraft({ ...draft, [name]: [] }); setAppearanceDraft({ ...appearanceDraft, [name]: newAppearance }); setNewCategory(""); setNewAppearance({ icon:"shopping", color:CATEGORY_COLOR_CHOICES[(Object.keys(draft).length + 1) % CATEGORY_COLOR_CHOICES.length] }); } };
  const addSub = (category:string) => { const value = (newSubs[category] ?? "").trim(); if (value && !draft[category].includes(value)) { setDraft({ ...draft, [category]: [...draft[category], value] }); setNewSubs({ ...newSubs, [category]: "" }); } };
  const picker = (value: CategoryAppearance, update: (next: CategoryAppearance) => void) => <div className="mt-3 rounded-xl bg-[#f5f0e5] p-3"><Label>Escoge un icono</Label><div className="mt-2 grid grid-cols-8 gap-2">{ICON_CHOICES.map((key) => { const Icon = CATEGORY_ICONS[key]; return <button key={key} type="button" title={key} aria-label={`Icono ${key}`} onClick={() => update({ ...value, icon:key })} className={`grid aspect-square place-items-center rounded-lg border bg-white ${value.icon === key ? "border-[#173c3a] ring-2 ring-[#2f6b65]/20" : "border-[#d8cdae]"}`}><Icon className="size-4"/></button>; })}</div><Label className="mt-3 block">Escoge un color</Label><div className="mt-2 flex flex-wrap gap-2">{CATEGORY_COLOR_CHOICES.map((color) => <button key={color} type="button" aria-label={`Color ${color}`} onClick={() => update({ ...value, color })} className={`size-7 rounded-full border-2 ${value.color === color ? "border-[#173c3a] ring-2 ring-offset-2" : "border-white"}`} style={{ backgroundColor:color }}/>)}</div></div>;
  return <Sheet open={open} onOpenChange={(value) => !value && onClose()}><SheetContent side="bottom" className="max-h-[94vh] overflow-y-auto rounded-t-[28px] bg-[#fffdf8] text-[#173c3a] sm:left-1/2 sm:right-auto sm:w-full sm:max-w-2xl sm:-translate-x-1/2 sm:rounded-3xl"><SheetHeader><SheetTitle className="font-serif text-2xl text-[#173c3a]">Categorías y subcategorías</SheetTitle></SheetHeader><div className="space-y-4 px-4"><section className="rounded-2xl border border-[#d8cdae] bg-white p-4"><div className="flex items-center gap-2"><CategoryIcon category="__new" appearances={{ __new:newAppearance }}/><Input value={newCategory} onChange={(event) => setNewCategory(event.target.value)} placeholder="Nombre de la nueva categoría" className="bg-white text-[#173c3a]"/><Button onClick={addCategory} disabled={!newCategory.trim()} className="bg-[#2f6b65] text-white"><Plus/>Agregar</Button></div>{picker(newAppearance,setNewAppearance)}</section>{Object.entries(draft).map(([category,subs], index) => { const appearance = getCategoryAppearance(category,appearanceDraft,index); return <section key={category} className="rounded-xl border p-3" style={{ borderColor:`${appearance.color}55`, backgroundColor:`${appearance.color}0d` }}><div className="flex items-center gap-3"><CategoryIcon category={category} appearances={appearanceDraft}/><b className="flex-1">{category}</b><Button variant="outline" size="sm" onClick={() => setActivePicker(activePicker === category ? null : category)}><Pencil className="size-3"/>Icono y color</Button><Button variant="ghost" size="icon" aria-label={`Eliminar ${category}`} onClick={() => { const next={...draft}; delete next[category]; const nextAppearances={...appearanceDraft}; delete nextAppearances[category]; setDraft(next); setAppearanceDraft(nextAppearances); }}><Trash2 className="size-4 text-[#b95f4d]"/></Button></div>{activePicker === category && picker(appearance,(next) => setAppearanceDraft({ ...appearanceDraft,[category]:next }))}<div className="mt-3 flex flex-wrap gap-2">{subs.map((sub) => <span key={sub} className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs">{sub}<button aria-label={`Eliminar ${sub}`} onClick={() => setDraft({ ...draft, [category]: subs.filter((item) => item !== sub) })}><X className="size-3"/></button></span>)}</div><div className="mt-3 flex gap-2"><Input value={newSubs[category] ?? ""} onChange={(event) => setNewSubs({ ...newSubs, [category]: event.target.value })} placeholder="Nueva subcategoría" className="bg-white text-[#173c3a]"/><Button variant="outline" onClick={() => addSub(category)}>Agregar</Button></div></section>; })}</div><SheetFooter><Button onClick={() => onSave(draft,withDefaultAppearances(draft,appearanceDraft))} disabled={!Object.keys(draft).length} className="bg-[#2f6b65] text-white">Guardar categorías</Button></SheetFooter></SheetContent></Sheet>;
}

function PaymentMethodsSheet({ open, methods, onClose, onSave }: { open: boolean; methods: string[]; onClose: () => void; onSave: (value: string[]) => void }) {
  const [draft, setDraft] = useState(methods); const [newMethod, setNewMethod] = useState("");
  useEffect(() => setDraft(methods), [methods, open]);
  const addMethod = (value = newMethod) => { const name = value.trim(); if (name && !draft.some((item) => normalize(item) === normalize(name))) { setDraft([...draft, name]); setNewMethod(""); } };
  const suggestions = DEFAULT_PAYMENT_METHODS.filter((method) => !draft.some((item) => normalize(item) === normalize(method)));
  return <Sheet open={open} onOpenChange={(value) => !value && onClose()}><SheetContent side="bottom" className="max-h-[92vh] overflow-y-auto rounded-t-[28px] bg-[#fffdf8] text-[#173c3a] sm:left-1/2 sm:right-auto sm:w-full sm:max-w-xl sm:-translate-x-1/2 sm:rounded-3xl"><SheetHeader><SheetTitle className="font-serif text-2xl text-[#173c3a]">Medios de pago y cuentas</SheetTitle></SheetHeader><div className="space-y-4 px-4"><p className="text-sm leading-6 text-[#687771]">Agrega efectivo, billeteras, cuentas o tarjetas. En cada movimiento podrás indicar de dónde salió o ingresó el dinero.</p><div className="flex gap-2"><Input value={newMethod} onChange={(event) => setNewMethod(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") addMethod(); }} placeholder="Ej. Mi tarjeta Ripley" className="bg-white text-[#173c3a]"/><Button onClick={() => addMethod()} className="bg-[#2f6b65] text-white"><Plus/>Agregar</Button></div><div className="overflow-hidden rounded-xl border border-[#d8cdae] bg-white">{draft.map((method) => <div key={method} className="flex items-center gap-3 border-b border-[#e5dcc8] p-3 last:border-0"><CreditCard className="size-4 text-[#2f6b65]"/><span className="flex-1 text-sm">{method}</span><Button variant="ghost" size="icon" aria-label={`Eliminar ${method}`} onClick={() => setDraft(draft.filter((item) => item !== method))}><Trash2 className="size-4 text-[#b95f4d]"/></Button></div>)}</div>{suggestions.length > 0 && <div><Label>Sugerencias</Label><div className="mt-2 flex flex-wrap gap-2">{suggestions.map((method) => <button key={method} onClick={() => addMethod(method)} className="rounded-full border border-[#d8cdae] bg-white px-3 py-1.5 text-xs hover:bg-[#e1eee8]">+ {method}</button>)}</div></div>}</div><SheetFooter><Button disabled={!draft.length} onClick={() => onSave(draft)} className="bg-[#2f6b65] text-white">Guardar medios de pago</Button></SheetFooter></SheetContent></Sheet>;
}

function Field({ label, children }: { label:string; children:React.ReactNode }) { return <div><Label>{label}</Label><div className="mt-1">{children}</div></div>; }
